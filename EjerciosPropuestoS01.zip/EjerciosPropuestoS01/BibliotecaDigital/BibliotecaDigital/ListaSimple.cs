﻿using BibliotecaDigital;

public class ListaSimple<T>
{
    private Nodo<T> cabeza;

    public void Insertar(T dato)
    {
        Nodo<T> nuevo = new Nodo<T>(dato);
        nuevo.Siguiente = cabeza;
        cabeza = nuevo;
    }
    // Recorrer
    public void Recorrer()
    {
        if (cabeza == null)
        {
            Console.WriteLine("La lista está vacía.");
            return;
        }

        Nodo<T> actual = cabeza;
        while (actual != null)
        {
            Console.WriteLine(actual.Dato);
            actual = actual.Siguiente;
        }
    }
    // Eliminar
    public void Eliminar(Func<T, bool> criterio)
    {
        if (cabeza == null)
        {
            Console.WriteLine("La lista está vacía.");
            return;
        }

        if (criterio(cabeza.Dato))
        {
            cabeza = cabeza.Siguiente;
            Console.WriteLine("Libro eliminado.");
            return;
        }

        Nodo<T> actual = cabeza;
        while (actual.Siguiente != null && !criterio(actual.Siguiente.Dato))
        {
            actual = actual.Siguiente;
        }

        if (actual.Siguiente != null)
        {
            actual.Siguiente = actual.Siguiente.Siguiente;
            Console.WriteLine("Libro eliminado.");
        }
        else
        {
            Console.WriteLine("Libro no encontrado.");
        }
    }
}

public class Libro
{
    public string? Codigo { get; set; }
    public string? Titulo { get; set; }
    public string? Autor { get; set; }
    public string? Estado { get; set; } // Disponible / Prestado

    public override string ToString()
    {
        return $"[Libro] Código: {Codigo}, Título: {Titulo}, Autor: {Autor}, Estado: {Estado}";
    }
}
