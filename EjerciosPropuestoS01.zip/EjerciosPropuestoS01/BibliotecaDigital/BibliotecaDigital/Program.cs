﻿class Program
{
    static void Main(string[] args)
    {
        ListaSimple<Libro> listaLibros = new ListaSimple<Libro>();
        int op;

        do
        {
            Console.WriteLine("\n--- Biblioteca Digital ---");
            Console.WriteLine("1. Insertar libro");
            Console.WriteLine("2. Mostrar libros");
            Console.WriteLine("3. Eliminar libro");
            Console.WriteLine("0. Salir");
            Console.Write("Opción: ");
            op = int.Parse(Console.ReadLine());

            switch (op)
            {
                case 1:
                    Libro l = new Libro();
                    Console.Write("Código: "); l.Codigo = Console.ReadLine();
                    Console.Write("Título: "); l.Titulo = Console.ReadLine();
                    Console.Write("Autor: "); l.Autor = Console.ReadLine();
                    Console.Write("Estado (disponible/prestado): "); l.Estado = Console.ReadLine();
                    listaLibros.Insertar(l);
                    break;

                case 2:
                    listaLibros.Recorrer();
                    break;

                case 3:
                    Console.Write("Ingrese código del libro a eliminar: ");
                    string cod = Console.ReadLine();
                    listaLibros.Eliminar(x => x.Codigo == cod);
                    break;
            }

        } while (op != 0);
    }
}
