﻿using Registro_de_citas_médicas;

class Program
{
    static void Main(string[] args)
    {
        ListaSimple<CitaMedica> listaCitas = new ListaSimple<CitaMedica>();
        int op;
        do
        {
            Console.WriteLine("\n--- Registro de Citas Médicas ---");
            Console.WriteLine("1. Insertar cita");
            Console.WriteLine("2. Mostrar citas");
            Console.WriteLine("3. Eliminar cita");
            Console.WriteLine("0. Salir");
            Console.Write("Opción: ");
            op = int.Parse(Console.ReadLine());

            switch (op)
            {
                case 1:
                    CitaMedica c = new CitaMedica();
                    Console.Write("Código de cita: "); c.CodigoCita = Console.ReadLine();
                    Console.Write("Paciente: "); c.Paciente = Console.ReadLine();
                    Console.Write("Especialidad: "); c.Especialidad = Console.ReadLine();
                    Console.Write("Fecha: "); c.Fecha = Console.ReadLine();
                    listaCitas.Insertar(c);
                    break;
                case 2:
                    listaCitas.Recorrer();
                    break;
                case 3:
                    Console.Write("Ingrese código de la cita a eliminar: ");
                    string codigo = Console.ReadLine();
                    listaCitas.Eliminar(x => x.CodigoCita == codigo);
                    break;
            }
        } while (op != 0);
    }
}

