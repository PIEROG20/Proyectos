﻿using RegistroCitasMedicas;
using System;

namespace Registro_de_citas_médicas
{
        public class ListaSimple<T>
        {
            private Nodo<T>? cabeza;

            public void Insertar(T dato)
            {
                Nodo<T> nuevo = new Nodo<T>(dato);
                nuevo.Siguiente = cabeza;
                cabeza = nuevo;
            }
        //Recorrer
            public void Recorrer()
            {
                if (cabeza == null)
                {
                    Console.WriteLine("La lista está vacía.");
                    return;
                }

                Nodo<T> actual = cabeza;
                while (actual != null)
                {
                    Console.WriteLine(actual.Dato);
                    actual = actual.Siguiente;
                }
            }
        // Eliminar
        public void Eliminar(Func<T, bool> criterio)
            {
                if (cabeza == null)
                {
                    Console.WriteLine("La lista está vacía.");
                    return;
                }

                if (criterio(cabeza.Dato))
                {
                    cabeza = cabeza.Siguiente;
                    Console.WriteLine("Cita eliminada.");
                    return;
                }

                Nodo<T> actual = cabeza;
                while (actual.Siguiente != null && !criterio(actual.Siguiente.Dato))
                {
                    actual = actual.Siguiente;
                }

                if (actual.Siguiente != null)
                {
                    actual.Siguiente = actual.Siguiente.Siguiente;
                    Console.WriteLine("Cita eliminada.");
                }
                else
                {
                    Console.WriteLine("Cita no encontrada.");
                }
            }
        }

        public class CitaMedica
        {
            public string? CodigoCita { get; set; }
            public string? Paciente { get; set; }
            public string? Especialidad { get; set; }
            public string? Fecha { get; set; }

            public override string ToString()
            {
                return $"[Cita] Código: {CodigoCita}, Paciente: {Paciente}, Especialidad: {Especialidad}, Fecha: {Fecha}";
            }
        }
    }

