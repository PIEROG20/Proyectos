﻿using System;

namespace EjerciosPropuestosS01
{
    internal class ListasSimples
    {
        public class ListaSimple<T>
        {
            private Nodo<T>? cabeza;

            public void Insertar(T dato)
            {
                Nodo<T> nuevo = new Nodo<T>(dato);
                nuevo.Siguiente = cabeza;
                cabeza = nuevo;
            }
            // recorrer
            public void Recorrer()
            {
                if (cabeza == null)
                {
                    Console.WriteLine("La lista está vacía.");
                    return;
                }

                Nodo <T> actual = cabeza;
                while (actual != null)
                {
                    Console.WriteLine(actual.Dato);
                    actual = actual.Siguiente;                
                }
            }
            // Eliminar 
            public void Eliminar(Func<T, bool> criterio)
            {
                if (cabeza == null)
                {
                    Console.WriteLine("La lista está vacía.");
                    return;
                }

                if (criterio(cabeza.Dato))
                {
                    cabeza = cabeza.Siguiente;
                    Console.WriteLine("Pedido eliminado.");
                    return;
                }

                Nodo<T> actual = cabeza;
                while (actual.Siguiente != null && !criterio(actual.Siguiente.Dato))
                {
                    actual = actual.Siguiente;
                }

                if (actual.Siguiente != null)
                {
                    actual.Siguiente = actual.Siguiente.Siguiente;
                    Console.WriteLine("Pedido eliminado.");
                }
                else
                {
                    Console.WriteLine("Pedido no encontrado.");
                }
            }
        }
        // pedido
        public class Pedido
        {
            public string? NumeroPedido { get; set; }
            public string? Cliente { get; set; }
            public string? Plato { get; set; }
            public double Monto { get; set; }

            public override string ToString()
            {
                return $"[Pedido] N°: {NumeroPedido}, Cliente: {Cliente}, Plato: {Plato}, Monto: {Monto:C}";
            }
        }
    }
}
