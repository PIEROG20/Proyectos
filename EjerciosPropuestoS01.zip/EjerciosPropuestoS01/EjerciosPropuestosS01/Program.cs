﻿using static EjerciosPropuestosS01.ListasSimples;

class Program
{
    static void Main(string[] args)
    {
        ListaSimple<Pedido> listaPedidos = new ListaSimple<Pedido>();
        int op;
        do
        {
            Console.WriteLine("\n--- Gestión de Pedidos ---");
            Console.WriteLine("1. Insertar pedido");
            Console.WriteLine("2. Mostrar pedidos");
            Console.WriteLine("3. Eliminar pedido");
            Console.WriteLine("0. Salir");
            Console.Write("Opción: ");
            op = int.Parse(Console.ReadLine());

            switch (op)
            {
                case 1:
                    Pedido p = new Pedido();
                    Console.Write("Número de Pedido: "); p.NumeroPedido = Console.ReadLine();
                    Console.Write("Cliente: "); p.Cliente = Console.ReadLine();
                    Console.Write("Plato: "); p.Plato = Console.ReadLine();
                    Console.Write("Monto: "); p.Monto = double.Parse(Console.ReadLine());
                    listaPedidos.Insertar(p);
                    break;
                case 2:
                    listaPedidos.Recorrer();
                    break;
                case 3:
                    Console.Write("Ingrese número de pedido a eliminar: ");
                    string num = Console.ReadLine();
                    listaPedidos.Eliminar(x => x.NumeroPedido == num);
                    break;
            }
        } 
        while (op != 0);
    }
}
