﻿using BusquedaCuentaBancaria;

class ListaCuentas
{
    private NodoCuenta? cabeza;

    public ListaCuentas()
    {
        cabeza = null;
    }

    // Inserta una cuenta al final de la lista
    public void InsertarCuenta(string numeroCuenta, string nombreCliente, double saldo)
    {
        NodoCuenta nuevaCuenta = new NodoCuenta(numeroCuenta, nombreCliente, saldo);

        if (cabeza == null)
        {
            cabeza = nuevaCuenta;
        }
        else
        {
            NodoCuenta actual = cabeza;
            while (actual.Siguiente != null)
            {
                actual = actual.Siguiente;
            }
            actual.Siguiente = nuevaCuenta;
        }
    }

    // Muestra todas las cuentas
    public void MostrarCuentas()
    {
        NodoCuenta? actual = cabeza;
        while (actual != null)
        {
            Console.WriteLine($"Cuenta: {actual.NumeroCuenta} | Cliente: {actual.NombreCliente} | Saldo: ${actual.Saldo:F2}");
            actual = actual.Siguiente;
        }
        Console.WriteLine();
    }

    // Busca una cuenta por número de cuenta
    public NodoCuenta? BuscarCuenta(string numeroBuscado)
    {
        NodoCuenta? actual = cabeza;
        while (actual != null)
        {
            if (actual.NumeroCuenta == numeroBuscado)
            {
                return actual; // Cuenta encontrada
            }
            actual = actual.Siguiente;
        }
        return null; // No encontrada
    }
}