﻿using System;

namespace BusquedaCuentaBancaria
{
    // Nodo que representa una cuenta bancaria
    class NodoCuenta
    {
        public string NumeroCuenta;
        public string NombreCliente;
        public double Saldo;
        public NodoCuenta? Siguiente;

        public NodoCuenta(string numeroCuenta, string nombreCliente, double saldo)
        {
            NumeroCuenta = numeroCuenta;
            NombreCliente = nombreCliente;
            Saldo = saldo;
            Siguiente = null;
        }
    }
}