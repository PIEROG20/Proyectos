﻿using BusquedaCuentaBancaria;

class Program
{
    static void Main(string[] args)
    {
        ListaCuentas banco = new ListaCuentas();

        // Insertar algunas cuentas
        banco.InsertarCuenta("001", "Ana Torres", 2500.00);
        banco.InsertarCuenta("002", "Luis Ramírez", 1500.50);
        banco.InsertarCuenta("003", "Carlos Pérez", 3200.75);

        Console.WriteLine("Cuentas en el sistema:");
        banco.MostrarCuentas();

        // Solicitar búsqueda al usuario
        Console.Write("Ingrese el número de cuenta a buscar: ");
        string numeroBusqueda = Console.ReadLine();

        NodoCuenta resultado = banco.BuscarCuenta(numeroBusqueda);

        if (resultado != null)
        {
            Console.WriteLine("\nCuenta encontrada:");
            Console.WriteLine($"Número de cuenta: {resultado.NumeroCuenta}");
            Console.WriteLine($"Nombre del cliente: {resultado.NombreCliente}");
            Console.WriteLine($"Saldo disponible: ${resultado.Saldo:F2}");
        }
        else
        {
            Console.WriteLine("\nCuenta no encontrada.");
        }
    }
}

