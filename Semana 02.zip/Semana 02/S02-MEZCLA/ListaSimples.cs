﻿// Lista enlazada simple
using MezclaListasCuentas;

class ListaCuentas
{
    public NodoCuenta? Cabeza;

    public ListaCuentas()
    {
        Cabeza = null;
    }

    // Inserta una cuenta en orden por número de cuenta
    public void InsertarEnOrden(string numeroCuenta, string nombreCliente, double saldo)
    {
        NodoCuenta nuevo = new NodoCuenta(numeroCuenta, nombreCliente, saldo);

        if (Cabeza == null || string.Compare(nuevo.NumeroCuenta, Cabeza.NumeroCuenta) < 0)
        {
            nuevo.Siguiente = Cabeza;
            Cabeza = nuevo;
        }
        else
        {
            NodoCuenta actual = Cabeza;
            while (actual.Siguiente != null && string.Compare(actual.Siguiente.NumeroCuenta, nuevo.NumeroCuenta) < 0)
            {
                actual = actual.Siguiente;
            }
            nuevo.Siguiente = actual.Siguiente;
            actual.Siguiente = nuevo;
        }
    }

    // Muestra todas las cuentas
    public void MostrarCuentas()
    {
        NodoCuenta? actual = Cabeza;
        while (actual != null)
        {
            Console.WriteLine($"Cuenta: {actual.NumeroCuenta} | Cliente: {actual.NombreCliente} | Saldo: ${actual.Saldo:F2}");
            actual = actual.Siguiente;
        }
        Console.WriteLine();
    }

    // Método estático para mezclar dos listas ordenadas
    public static ListaCuentas MezclarListas(ListaCuentas lista1, ListaCuentas lista2)
    {
        ListaCuentas resultado = new ListaCuentas();

        NodoCuenta? p1 = lista1.Cabeza;
        NodoCuenta? p2 = lista2.Cabeza;
        NodoCuenta? pRes = null;

        while (p1 != null && p2 != null)
        {
            NodoCuenta menor;

            if (string.Compare(p1.NumeroCuenta, p2.NumeroCuenta) <= 0)
            {
                menor = new NodoCuenta(p1.NumeroCuenta, p1.NombreCliente, p1.Saldo);
                p1 = p1.Siguiente;
            }
            else
            {
                menor = new NodoCuenta(p2.NumeroCuenta, p2.NombreCliente, p2.Saldo);
                p2 = p2.Siguiente;
            }

            if (resultado.Cabeza == null)
            {
                resultado.Cabeza = menor;
                pRes = menor;
            }
            else
            {
                pRes.Siguiente = menor;
                pRes = menor;
            }
        }

        // Agregar lo que quede de una de las listas
        NodoCuenta restante = p1 ?? p2;
        while (restante != null)
        {
            NodoCuenta nuevo = new NodoCuenta(restante.NumeroCuenta, restante.NombreCliente, restante.Saldo);
            if (resultado.Cabeza == null)
            {
                resultado.Cabeza = nuevo;
                pRes = nuevo;
            }
            else
            {
                pRes.Siguiente = nuevo;
                pRes = nuevo;
            }
            restante = restante.Siguiente;
        }

        return resultado;
    }
}