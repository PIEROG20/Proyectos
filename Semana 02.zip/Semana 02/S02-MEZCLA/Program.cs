﻿// Programa principal
class Program
{
    static void Main(string[] args)
    {
        // Lista de Sucursal A
        ListaCuentas sucursalA = new ListaCuentas();
        sucursalA.InsertarEnOrden("001", "Ana Torres", 2500.00);
        sucursalA.InsertarEnOrden("003", "Luis Ramírez", 3200.75);
        sucursalA.InsertarEnOrden("005", "María Gómez", 4100.50);

        // Lista de Sucursal B
        ListaCuentas sucursalB = new ListaCuentas();
        sucursalB.InsertarEnOrden("002", "Carlos Pérez", 1500.30);
        sucursalB.InsertarEnOrden("004", "Sandra López", 2800.00);
        sucursalB.InsertarEnOrden("006", "Pedro Díaz", 5000.00);

        Console.WriteLine("Sucursal A:");
        sucursalA.MostrarCuentas();

        Console.WriteLine("Sucursal B:");
        sucursalB.MostrarCuentas();

        // Mezclar listas
        ListaCuentas listaUnificada = ListaCuentas.MezclarListas(sucursalA, sucursalB);

        Console.WriteLine("Lista combinada y ordenada por número de cuenta:");
        listaUnificada.MostrarCuentas();
    }
}