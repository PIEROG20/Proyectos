﻿class Program
{
    static void Main(string[] args)
    {
        ListaCuentas banco = new ListaCuentas();

        // Insertar cuentas
        banco.InsertarCuenta("001", "Ana Torres", 2500.00);
        banco.InsertarCuenta("002", "Luis Ramírez", 1500.50);
        banco.InsertarCuenta("003", "Carlos Pérez", 3200.75);
        banco.InsertarCuenta("004", "María Gómez", 1000.25);

        Console.WriteLine("Lista antes de ordenar:");
        banco.MostrarCuentas();

        banco.OrdenarPorSaldo();

        Console.WriteLine("Lista después de ordenar por saldo:");
        banco.MostrarCuentas();
    }
}
