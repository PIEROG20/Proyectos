﻿// Clase ListaCuentas: Lista enlazada simple
using OrdenamientoCuentasBancarias;

class ListaCuentas
{
    private NodoCuenta? cabeza;

    public ListaCuentas()
    {
        cabeza = null;
    }

    // Insertar una nueva cuenta al final
    public void InsertarCuenta(string numeroCuenta, string nombreCliente, double saldo)
    {
        NodoCuenta nuevaCuenta = new NodoCuenta(numeroCuenta, nombreCliente, saldo);

        if (cabeza == null)
        {
            cabeza = nuevaCuenta;
        }
        else
        {
            NodoCuenta actual = cabeza;
            while (actual.Siguiente != null)
            {
                actual = actual.Siguiente;
            }
            actual.Siguiente = nuevaCuenta;
        }
    }

    // Mostrar cuentas
    public void MostrarCuentas()
    {
        NodoCuenta actual = cabeza;
        while (actual != null)
        {
            Console.WriteLine($"Cuenta: {actual.NumeroCuenta} | Cliente: {actual.NombreCliente} | Saldo: ${actual.Saldo:F2}");
            actual = actual.Siguiente;
        }
        Console.WriteLine();
    }

    // Ordenar por saldo (algoritmo de inserción)
    public void OrdenarPorSaldo()
    {
        NodoCuenta? ordenada = null;

        NodoCuenta actual = cabeza;
        while (actual != null)
        {
            NodoCuenta? siguiente = actual.Siguiente;
            ordenada = InsertarOrdenado(ordenada, actual);
            actual = siguiente;
        }

        cabeza = ordenada;
    }

    private NodoCuenta InsertarOrdenado(NodoCuenta cabezaOrdenada, NodoCuenta nuevoNodo)
    {
        if (cabezaOrdenada == null || nuevoNodo.Saldo < cabezaOrdenada.Saldo)
        {
            nuevoNodo.Siguiente = cabezaOrdenada;
            return nuevoNodo;
        }
        else
        {
            NodoCuenta actual = cabezaOrdenada;
            while (actual.Siguiente != null && actual.Siguiente.Saldo <= nuevoNodo.Saldo)
            {
                actual = actual.Siguiente;
            }
            nuevoNodo.Siguiente = actual.Siguiente;
            actual.Siguiente = nuevoNodo;
            return cabezaOrdenada;
        }
    }
}
