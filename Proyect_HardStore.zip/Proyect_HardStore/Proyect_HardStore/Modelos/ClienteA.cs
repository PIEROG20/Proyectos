﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace Proyect_HardStore
{
    public class ClienteA
    { 
        public string Ticket { get; set; }
        public string Cliente { get; set; }
        public string Atencion { get; set; }
        // Propiedad de compatibilidad para código que use "TipoAtencion"
        public string TipoAtencion { get => Atencion; set => Atencion = value; }
        public DateTime FechaAtencion { get; set; }
    }
}
