﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyect_HardStore
{
    public class Producto
    { 
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public int Cantidad { get; set; }
        public string Proveedor { get; set; }
        public double Precio { get; set; }
        public string Unidad { get; set;  }
        public string Categoria { get; set; }
        public DateTime FechaRegistro { get; set; }
    }
}
