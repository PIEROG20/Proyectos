﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyect_HardStore
{
    public class Usuario
    {
        public string NombreApellido { get; set; }
        public int Telefono { get; set; }
        public string Direccion { get; set; }
        public string Correo { get; set; }
        public int DNI { get; set; }
        public string TipoUsuario { get; set; }
        public int IDtrabajador { get; set; }
        public string Cargo { get; set; }
        public string usuario { get; set; }
        public string Contraseña { get; set; }

        public Usuario(string nombreApellido, int telefono, string direccion, string correo, int Dni , string tipoUsuario,int IdTrabajador, string cargo, string usuario, string contraseña)
        {
            NombreApellido = nombreApellido;
            Telefono = telefono;
            Direccion = direccion;
            Correo = correo;
            DNI = Dni;
            TipoUsuario = tipoUsuario;
            IDtrabajador = IdTrabajador;
            Cargo = cargo;
            this.usuario = usuario;
            Contraseña = contraseña;
        }
        public string ConvertirACsv()
        {
            return $"{NombreApellido},{Telefono},{Direccion},{Correo},{DNI},{TipoUsuario},{IDtrabajador},{Cargo},{usuario},{Contraseña}";
        }

        public static Usuario CrearDesdeCsv(string linea)
        {
            var partes = linea.Split(',');

            return new Usuario(
                partes[0],
                int.Parse(partes[1]),
                partes[2],
                partes[3],
                int.Parse(partes[4]),
                partes[5],
                int.Parse(partes[6]),
                partes[7],
                partes[8],
                partes[9]
            );
        }
    }
}
