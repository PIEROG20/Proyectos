﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyect_HardStore
{
    // MODELO , DEL LOS DATOS NECESARIO DEL PRODUCTO 
    public class PedidoProducto
    {
        public string Producto { get; set; }
        public string Codigo { get; set; }
        public int CantidadPedida { get; set; }
        public double PrecioUNI { get; set; }
        public double PrecioTL { get; set; }
    }
}
