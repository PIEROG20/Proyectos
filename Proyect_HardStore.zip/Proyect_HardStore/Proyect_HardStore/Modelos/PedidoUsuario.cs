﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    // MODELO DEL PEDIDO , UNCLUYE LOS DATOS Y LA LISTA DE PRODUCTO DEL CLIENTE 
    public class PedidoUsuario
    {
        public int IDpedido { get; set; }
        public string NombreAppellidos { get; set; }
        public int Telefono { get; set; }
        public int DNI { get; set; }
        public string Ticket { get; set; }
        public List<PedidoProducto> ListaProductos { get; set; }
        public string MetodoPago { get; set; }
        public string TipoEntrega { get; set; }
        public DateTime FechaPedido { get; set; }
        public string Direccion { get; set; }
        public string Referencia { get; set; }
        public string Distrito { get; set; }
        public double PrecioEnvio { get; set; }

        public PedidoUsuario()
        {
            ListaProductos = new List<PedidoProducto>();
        }

    }
}
