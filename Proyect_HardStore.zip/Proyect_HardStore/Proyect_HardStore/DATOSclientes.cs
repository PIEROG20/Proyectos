﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    public class DATOSclientes
    {
        public int G6_ID {  get; set; }
        public string G6_DNI { get; set; }
        public string G6_Nombres { get; set; }
        public string G6_Apellidos { get; set; }
        public string G6_Celular { get; set; }
        public const int G6_TamañoRegistro = 4 + (8 + 50 + 50 + 9) * 2;
        
    }
    public static class BaseDatosClientes
    {

        public static string BDclientes = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Base De Datos", "cliente.dat");

        public static List<DATOSclientes> G6_Clientes = new List<DATOSclientes>();
        public static byte[] ConvertirAbyte(DATOSclientes G6_cliente)
        {
            using(var G6_MemS = new MemoryStream())
            using(var G6_EscBinario = new BinaryWriter(G6_MemS, Encoding.Unicode))
            {
                G6_EscBinario.Write(G6_cliente.G6_ID);
                G6_EscBinario.Write(G6_cliente.G6_DNI.PadRight(8).ToCharArray());
                G6_EscBinario.Write(G6_cliente.G6_Nombres.PadRight(50).ToCharArray());
                G6_EscBinario.Write(G6_cliente.G6_Apellidos.PadRight(50).ToCharArray());
                G6_EscBinario.Write(G6_cliente.G6_Celular.PadRight(9).ToCharArray());
                return G6_MemS.ToArray();
            }
        }
        public static DATOSclientes LeerDesdeByte(byte[] G6_datos)
        {
            if (G6_datos == null || G6_datos.Length < DATOSclientes.G6_TamañoRegistro)
                throw new ArgumentException("El bloque");
            using (var G6_MemS = new MemoryStream(G6_datos))
            using(var G6_LectBinario = new BinaryReader(G6_MemS, Encoding.Unicode))
            {
                return new DATOSclientes
                {
                    G6_ID = G6_LectBinario.ReadInt32(),
                    G6_DNI = new string(G6_LectBinario.ReadChars(8)).Trim(),
                    G6_Nombres = new string(G6_LectBinario.ReadChars(50)).Trim(),
                    G6_Apellidos = new string(G6_LectBinario.ReadChars(50)).Trim(),
                    G6_Celular = new string(G6_LectBinario.ReadChars(9)).Trim()
                };
            }
        }
        public static void CargarDatosDeClientes()
        {
            G6_Clientes.Clear();
            if (!File.Exists(BDclientes))
                return;
            using(FileStream G6_fs = new FileStream(BDclientes, FileMode.Open,FileAccess.Read))            
            {
                byte[] G6_buffer = new byte[DATOSclientes.G6_TamañoRegistro];
                while (G6_fs.Position + DATOSclientes.G6_TamañoRegistro<= G6_fs.Length)
                {
                    int G6_bytesLeidos = G6_fs.Read(G6_buffer,0, G6_buffer.Length);
                    if(G6_bytesLeidos<G6_buffer.Length)
                        break;
                    DATOSclientes G6_cliente = LeerDesdeByte(G6_buffer);
                    G6_Clientes.Add(G6_cliente);
                    

                }
            }       
        }
        public static bool ExisteClienteXdniOcelular(string G6_dniComp, string G6_celularComp)
        {
            if (!File.Exists(BDclientes))
                return false;
            using(FileStream G6_fs = new FileStream(BDclientes,FileMode.Open,FileAccess.Read))
            {
                byte[] G6_buffer = new byte[DATOSclientes.G6_TamañoRegistro];
                while (G6_fs.Position + DATOSclientes.G6_TamañoRegistro <= G6_fs.Length) 
                {
                    G6_fs.Read(G6_buffer, 0, DATOSclientes.G6_TamañoRegistro);
                    var G6_cliente = LeerDesdeByte((G6_buffer));
                    if (G6_cliente.G6_DNI == G6_dniComp || G6_cliente.G6_Celular == G6_celularComp)
                        return true;
                }
            }
            return false;
        }

        
        public static void AgregarCliente(DATOSclientes G6_nuevoCliente)
        {
            using (FileStream G6_fs = new FileStream(BDclientes,FileMode.Append,FileAccess.Write))
            {
                byte[] G6_buffer = ConvertirAbyte(G6_nuevoCliente);
                G6_fs.Write(G6_buffer,0, G6_buffer.Length);
            }
        }
        public static DATOSclientes BuscarXID(int G6_id)
        {
            return G6_Clientes.Find(c => c.G6_ID == G6_id);

            
        }
        public static bool EliminarClienteXID(int G6_id, out string G6_mensaje)
        {
            G6_mensaje = "cliente no encontrado";
            if (!File.Exists(BDclientes))
            {
                G6_mensaje ="archivo inexistente";
                return false;
            }
            string G6_tempDatos = "clientes_temp.dat";
            bool G6_eliminado = false;
            using(FileStream G6_Origen = new FileStream(BDclientes, FileMode.Open, FileAccess.Read))
            using (FileStream G6_destino = new FileStream(G6_tempDatos, FileMode.Create, FileAccess.Write))
            {
                byte[] G6_buffer = new byte[DATOSclientes.G6_TamañoRegistro];
                while (G6_Origen.Position + DATOSclientes.G6_TamañoRegistro <= G6_Origen.Length)
                {
                    G6_Origen.Read(G6_buffer, 0, DATOSclientes.G6_TamañoRegistro);
                    DATOSclientes G6_cliente = LeerDesdeByte(G6_buffer);
                    if (G6_cliente.G6_ID == G6_id)
                    {
                        G6_eliminado = true;
                        continue;
                    }
                    G6_destino.Write(G6_buffer, 0, DATOSclientes.G6_TamañoRegistro);
                }

            }
            if (G6_eliminado)
            {
                File.Delete(BDclientes);
                File.Move(G6_tempDatos, BDclientes);

                return true;
            }
            else
            {
                File.Delete(G6_tempDatos);
                return false;
            }
        }
        public static int GeneradorIDs()
        {
            int G6_UltimoID = 0;
            if (!File.Exists(BDclientes))
                return 1;
            using (FileStream G6_Fs = new FileStream(BDclientes, FileMode.Open, FileAccess.Read))
            {
                byte[] G6_buffer = new byte[DATOSclientes.G6_TamañoRegistro];
                while (G6_Fs.Position + DATOSclientes.G6_TamañoRegistro <= G6_Fs.Length)
                {
                    int G6_bytesleidos = G6_Fs.Read(G6_buffer, 0, G6_buffer.Length);
                    if (G6_bytesleidos < G6_buffer.Length)
                        break;
           
                    DATOSclientes G6_Cliente = LeerDesdeByte(G6_buffer);
                    if(G6_Cliente.G6_ID > G6_UltimoID) 
                        G6_UltimoID = G6_Cliente.G6_ID;
                }
            }
            return G6_UltimoID +1;
        }

    }
    
    public static class FuncionesClientes
    {
        public static DATOSclientes BuscarClienteXdni(string G6_DNIbuscado)
        {
            return BaseDatosClientes.G6_Clientes
                .FirstOrDefault(p => p.G6_DNI.Equals(G6_DNIbuscado, StringComparison.OrdinalIgnoreCase));
        }

    }
    
    public static class ValidarDigitos
    {
        public static void limitarDigitosEnTextBox(object sender, int maxDigitos)
        {
            if(sender is TextBox G6_digitos)
            {
                string G6_Validado = LimitarDigitos(G6_digitos.Text , maxDigitos);
                if (G6_digitos.Text != G6_Validado)
                {
                    G6_digitos.Text = G6_Validado;
                    G6_digitos.SelectionStart = G6_digitos.Text.Length;
                }
            }
        }
        public static string LimitarDigitos(string G6_Digitos, int G6_MaxDigitos)
        {
            string G6_SoloDigitos = new string(G6_Digitos.Where(char.IsDigit).ToArray());
            if (G6_SoloDigitos.Length > G6_MaxDigitos)
                return LimitarDigitos(G6_SoloDigitos.Substring(0,G6_SoloDigitos.Length - 1),G6_MaxDigitos);
            return G6_SoloDigitos;
        }
    }
}
