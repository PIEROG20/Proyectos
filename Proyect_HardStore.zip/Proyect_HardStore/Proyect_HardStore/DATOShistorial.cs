﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    public class DATOShistorial
    {
        public int G6_ID { get; set; }
        public string G6_CodigoProducto { get; set; }
        public string G6_NombreProducto {  get; set; }
        public string G6_Categoria { get; set; }
        public double G6_PrecioUnitario { get; set; }
        public int G6_Cantidad { get; set; }
        public double G6_MontoTotal { get; set; }
    }
    public static class BaseDatosHistorial
    {
        public static string BDhistorialClientes = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Base De Datos", "BD_HistorialCliente.csv");

        public static List<DATOShistorial> G6_HistorialClientes = new List<DATOShistorial>();

        public static void CargarDatosDeHistorialClientes()
        {
            G6_HistorialClientes.Clear();
            if (File.Exists(BDhistorialClientes))
            {

                string[] G6_lineas = File.ReadAllLines(BDhistorialClientes);
                for (int i = 1; i < G6_lineas.Length; i++)
                {
                    string[] G6_datosH = G6_lineas[i].Split(',');
                    DATOShistorial h = new DATOShistorial
                    {
                        G6_ID = int.Parse(G6_datosH[0]),
                        G6_CodigoProducto = G6_datosH[1],
                        G6_NombreProducto = G6_datosH[2],
                        G6_Categoria = G6_datosH[3],
                        G6_PrecioUnitario = double.Parse(G6_datosH[4]),
                        G6_Cantidad = int.Parse(G6_datosH[5]),
                        G6_MontoTotal = double.Parse(G6_datosH[6])
                    };
                    G6_HistorialClientes.Add(h);
                }
            }
            else
            {
                MessageBox.Show("ARCHIVOS NO ENCONTRADOS");
            }
        }
        public static void GuardarDatosHistorialClientes()
        {
            List<string> G6_Lineas = new List<string>();
            G6_Lineas.Add("ID del cliente,Codigo del producto,Nombre del producto,Categoria,Precio Unitario,Cantidad,Monto total");
            foreach (var c in BaseDatosHistorial.G6_HistorialClientes)
            {
                G6_Lineas.Add($"{c.G6_ID},{c.G6_CodigoProducto},{c.G6_NombreProducto},{c.G6_Categoria},{c.G6_PrecioUnitario},{c.G6_Cantidad},{c.G6_MontoTotal}");
            }
            File.WriteAllLines(BDhistorialClientes, G6_Lineas);
        }

        
    }
    
    public static class ListaCarrito
    {
        public static List<DATOSproductos> G6_CarritoTemp = new List<DATOSproductos>();
        
    }
}
