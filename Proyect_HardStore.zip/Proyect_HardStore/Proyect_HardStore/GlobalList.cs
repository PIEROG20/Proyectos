﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace Proyect_HardStore
{
    public static class DatosGlobales 
    {
        public static ListaEnlazadaP listP = new ListaEnlazadaP();
        public static List<PedidoProducto> Productos = new List<PedidoProducto>();
        public static Usuario UsuarioLogeado { get; set; }
        public static void LimpiarProductos()
        {
            Productos.Clear();
        }

        public static ArbolBinario ArbolGeneral = new ArbolBinario();
    }
}
