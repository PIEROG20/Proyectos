﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore.Metodo_Forms
{
    public class MetodoFormHijos
    {
        private Button BotonActual;
        private Random Random;
        private int indexTemp;
        private Form Formactivo;
        private Panel panelActivo, panelButtonsActivo;
        public Random random = new Random();
        private Color SeccionarColorTemaRandom()
        {
            int index = random.Next(ColorTema.ListaColores.Count);
            while (indexTemp == index)
            {
                index = random.Next(ColorTema.ListaColores.Count);
            }
            indexTemp = index;
            string Color = ColorTema.ListaColores[index];
            return ColorTranslator.FromHtml(Color);
        }
        /*
        private void Boton_Activo(object BTN_emisor, object PanelButtons)
        {
            if (PanelButtons != null)
            {
                Boton_desactivado(PanelButtons);
            }
            //Boton_desactivado(PanelButtons);
            if (BTN_emisor != null)
            {
                if (BotonActual != (Button)BTN_emisor)
                {
                    Color color = ColorTema.CambiarBrilloDelColor(Color.FromArgb(246, 191, 11), -0.3);
                    //Color color = SeccionarColorTemaRandom();
                    BotonActual = (Button)BTN_emisor;

                    BotonActual.BackColor = color;
                    BotonActual.ForeColor = Color.White;
                    BotonActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    //funcion para cambiar el tema entero por el color seleccionado solo que mas oscuro
                    //Planes para alguna otra cosa si no se usa sera borrado
                    //PanelBarTitulo.BackColor = G6_color;
                    //PanelG.BackColor = ColorTema.CambiarBrilloDelColor(G6_color, -0.3);
                    ColorTema.colorPrimario = color;
                    ColorTema.colorSecundario = ColorTema.CambiarBrilloDelColor(color, -0.3);
                }
            }
        }
        private void Boton_desactivado(object PanelButtons)
        {
            panelButtonsActivo = (Panel)PanelButtons;
            foreach (Control BtnPrevio in panelButtonsActivo.Controls)
            {
                if (BtnPrevio.GetType() == typeof(Button))
                {
                    BtnPrevio.BackColor = Color.FromArgb(246, 191, 11);
                    BtnPrevio.ForeColor = Color.White;
                    BtnPrevio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                }
            }
        }
        */

        public void abrirFormHijos(Form FormHijo, object BTN_emisor, object panel, object PanelButtons)
        {

            if (Formactivo != null)
            {
                Formactivo.Close();

            }
            //Boton_Activo(BTN_emisor, PanelButtons);
            Formactivo = FormHijo;
            panelActivo = (Panel)panel;
            FormHijo.TopLevel = false;
            FormHijo.FormBorderStyle = FormBorderStyle.None;
            FormHijo.Dock = DockStyle.Fill;
            this.panelActivo.Controls.Add(FormHijo);
            this.panelActivo.Tag = FormHijo;
            FormHijo.BringToFront();
            FormHijo.Show();

        }
    }
}
