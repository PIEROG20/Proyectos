﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{

    public class DATOSproductos
    {
        public string G6_Codigo { get; set; }
        public string G6_Nombre { get; set; }
        public string G6_Categoria { get; set; }
        public double G6_Precio { get; set; }
        public int G6_Cantidad { get; set; }
       

    }
    
    public  static class BaseDatosProductos
    {
        public static string BDproductos = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Base De Datos","producto.csv");
        
        public static List<DATOSproductos> G6_Productos = new List<DATOSproductos>();
        public static void CargarDatosDeProductos()
        {
            G6_Productos.Clear();
            if (File.Exists(BDproductos))
            {

                string[] G6_lineas = File.ReadAllLines(BDproductos);
                for (int i = 1; i < G6_lineas.Length; i++) 
                {
                    string[] G6_datosP = G6_lineas[i].Split(',');
                    DATOSproductos G6_productoCarga = new DATOSproductos
                    {
                        G6_Codigo = G6_datosP[0],
                        G6_Nombre = G6_datosP[1],
                        G6_Categoria = G6_datosP[2],
                        G6_Precio = double.Parse(G6_datosP[3]),
                        G6_Cantidad = int.Parse(G6_datosP[4])                    
                    };
                    G6_Productos.Add(G6_productoCarga);
                }
            }
            else
            {
                MessageBox.Show("ARCHIVOS NO ENCONTRADOS");
            }
        }
        public static void GuardarDatosProductos()
        {
            List<string>G6_Lineas = new List<string>();
            G6_Lineas.Add("Codigo,Nombre,Categoria,Precio,Cantidad");
            foreach (var G6_productosG in BaseDatosProductos.G6_Productos)
            {
                G6_Lineas.Add($"{G6_productosG.G6_Codigo},{G6_productosG.G6_Nombre},{G6_productosG.G6_Categoria},{G6_productosG.G6_Precio},{G6_productosG.G6_Cantidad}");
            }
            File.WriteAllLines(BDproductos, G6_Lineas);
        }
       

    }
    public static class FuncionesProductos
    {
        public static DATOSproductos BuscarProductoPorNombre(string G6_nombreBuscado, string G6_categorias)
        {
            return BaseDatosProductos.G6_Productos
                .FirstOrDefault(p => p.G6_Nombre.Equals(G6_nombreBuscado, StringComparison.OrdinalIgnoreCase)&& 
                p.G6_Categoria.Equals(G6_categorias, StringComparison.OrdinalIgnoreCase));
        }
        public static DATOSproductos BuscarProductoPorCodigo(string G6_CodigoBuscado)
        {
            return BaseDatosProductos.G6_Productos.FirstOrDefault(pc => pc.G6_Codigo.Equals(G6_CodigoBuscado, StringComparison.OrdinalIgnoreCase));
        }
        // QuickSort para ordenar por precio
        public static void QuickSortPorPrecio(bool G6_ascendente)
        {
            QuickSort(BaseDatosProductos.G6_Productos, 0, BaseDatosProductos.G6_Productos.Count - 1, G6_ascendente);
        }

        private static void QuickSort(List<DATOSproductos> G6_lista, int G6_izquierda, int G6_derecha, bool G6_asc)
        {
            if (G6_izquierda >= G6_derecha) return;

            int G6_pivoteIndex = Particionar(G6_lista, G6_izquierda, G6_derecha, G6_asc);
            QuickSort(G6_lista, G6_izquierda, G6_pivoteIndex - 1, G6_asc);
            QuickSort(G6_lista, G6_pivoteIndex + 1, G6_derecha, G6_asc);
        }

        private static int Particionar(List<DATOSproductos> G6_lista, int G6_izquierda, int G6_derecha, bool G6_asc)
        {
            double G6_pivote = G6_lista[G6_derecha].G6_Precio;
            int i = G6_izquierda - 1;

            for (int j = G6_izquierda; j < G6_derecha; j++)
            {
                bool G6_condicion = G6_asc ? G6_lista[j].G6_Precio <= G6_pivote : G6_lista[j].G6_Precio >= G6_pivote;
                if (G6_condicion)
                {
                    i++;
                    (G6_lista[i], G6_lista[j]) = (G6_lista[j], G6_lista[i]);
                }
            }

            (G6_lista[i + 1], G6_lista[G6_derecha]) = (G6_lista[G6_derecha], G6_lista[i + 1]);
            return i + 1;
        }
        public static int CalcularStockPorCategoria(string G6_categoria, int G6_indice = 0)
        {
            if (G6_indice >= BaseDatosProductos.G6_Productos.Count)
                return 0;

            var G6_p = BaseDatosProductos.G6_Productos[G6_indice];
            int G6_suma = G6_p.G6_Categoria.Equals(G6_categoria, StringComparison.OrdinalIgnoreCase) ? G6_p.G6_Cantidad : 0;
            return G6_suma + CalcularStockPorCategoria(G6_categoria, G6_indice + 1);
        }
        public static Dictionary<string, int> obtenerStockporCategoria()
        {
            var G6_categorias =BaseDatosProductos.G6_Productos.Select(p => p.G6_Categoria).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            return obtenerStockRecursivo(G6_categorias, 0, new Dictionary<string, int>());
        }
        public static Dictionary<string,int>obtenerStockRecursivo(List<string>G6_categorias,int G6_indice,Dictionary<string,int>G6_acumulador)
        {
            if(G6_indice>=G6_categorias.Count)
                return G6_acumulador;

            string G6_categoria  = G6_categorias[G6_indice];
            int G6_stock  = CalcularStockPorCategoria(G6_categoria);
            G6_acumulador[G6_categoria] = G6_stock;
            return obtenerStockRecursivo(G6_categorias, G6_indice + 1, G6_acumulador);

        }
        //Elimina un producto al selecionar una fila y precionar el boton eliminar
        public static void EliminarProductoXfila(DataGridView G6_TablaProduc, List<DATOSproductos> G6_listaProduc)
        {
            if (G6_TablaProduc.SelectedRows.Count > 0)
            {
                var G6_fila = G6_TablaProduc.SelectedRows[0];
                string G6_Codigo = G6_fila.Cells[0].Value.ToString();
                var G6_producto = G6_listaProduc.FirstOrDefault(p => p.G6_Codigo == G6_Codigo);
                if (G6_producto != null)
                {
                    G6_listaProduc.Remove(G6_producto);
                    G6_TablaProduc = null;
                    MessageBox.Show("producto Eliminado");
                }
            }
            else
            {
                MessageBox.Show("Selecione una fila primero");
            }
        }


    }
    public static class Usuarios
    {


        private static Dictionary<string, string> G6_usuarios = new Dictionary<string, string>()
        {
            {"Janpier","1234" },
            {"Sayuri19","080506" },
             {"Cristhofer","123456" },
            {"Andrea","12345" }
        };
        public static bool ValidarDatos(string G6_usuario, string G6_contraseña)
        {
            return G6_usuarios.TryGetValue(G6_usuario, out string G6_contraseñaguardada) && G6_contraseñaguardada == G6_contraseña;

        }
        public static bool ExisteUsuario(string G6_usuario)
        {
            return G6_usuarios.ContainsKey(G6_usuario);

        }
        
    }
    
    

}
