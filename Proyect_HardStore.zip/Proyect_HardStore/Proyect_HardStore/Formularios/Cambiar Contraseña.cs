﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Proyect_HardStore.Estructura_de_datos;

namespace Proyect_HardStore
{
    public partial class Cambiar_Contraseña : Form
    {
        public Cambiar_Contraseña()
        {
            InitializeComponent();
        }

        private void btncambiarcontraseña_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener usuario logeado
                var usuario = DatosGlobales.UsuarioLogeado;
                if (usuario == null)
                {
                    MessageBox.Show("No hay usuario logeado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string actual = txtcontraseñaactual.Text ?? string.Empty;
                string nuevo = txtnuevacontraseña.Text ?? string.Empty;
                string confirmar = txtconfirmarcontraseña.Text ?? string.Empty;

                // Validaciones
                if (string.IsNullOrWhiteSpace(actual) || string.IsNullOrWhiteSpace(nuevo) || string.IsNullOrWhiteSpace(confirmar))
                {
                    MessageBox.Show("Complete todos los campos.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (actual != usuario.Contraseña)
                {
                    MessageBox.Show("La contraseña actual no coincide.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (nuevo != confirmar)
                {
                    MessageBox.Show("La nueva contraseña y su confirmación no coinciden.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Actualizar en memoria
                usuario.Contraseña = nuevo;

                // Actualizar en la lista del repositorio y guardar
                var registro = BaseDeDatosUsuarios.BuscarUsuario(usuario.usuario);
                if (registro != null)
                {
                    registro.Contraseña = nuevo;
                    BaseDeDatosUsuarios.GuardarEnCsv();
                }

                MessageBox.Show("Contraseña cambiada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error cambiando contraseña: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

