﻿using Proyect_HardStore.Estructura_de_datos;
using Proyect_HardStore.Metodo_Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Proyect_HardStore
{
    public partial class Form1 : Form
    {
        MetodoFormHijos Metodoform = new MetodoFormHijos();
        public Form1()
        {
            InitializeComponent();
            BaseDeDatosUsuarios.CargarDesdeCsv();
            label4.BackColor = Color.Transparent;
            label4.Parent = pictureBox2;
            label5.BackColor = Color.Transparent;
            label5.Parent = pictureBox2;

        }

        public static GraphicsPath RedondearRectangulo(Rectangle rect, int radio)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(rect.X, rect.Y, radio, radio, 180, 90);
            path.AddArc(rect.Right - radio, rect.Y, radio, radio, 270, 90);
            path.AddArc(rect.Right - radio, rect.Bottom - radio, radio, radio, 0, 90);
            path.AddArc(rect.X, rect.Bottom - radio, radio, radio, 90, 90);
            path.CloseFigure();
            return path;
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        private void MoverVentana()
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }

        private void btnInciar_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;
            string contraseña = txtContraseña.Text;


            BaseDeDatosUsuarios.CargarDesdeCsv();

            if (ServicioAutenticacion.IniciarSesion(usuario, contraseña))
            {
                MessageBox.Show("Bienvenido " + usuario, "Acceso autorizado");
               

                Form_principal formP = new Form_principal(usuario);
                formP.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos", "Acceso denegado");
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            FormRegistrar formR = new FormRegistrar();
            formR.Show();
            this.Hide();
        }

        private void txtContraseña_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            MoverVentana();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            MoverVentana();
        }

        private void panelUsuario_Paint(object sender, PaintEventArgs e)
        {
            Panel p = sender as Panel;
            using (GraphicsPath path = RedondearRectangulo(p.ClientRectangle, 20))
            {
                p.Region = new Region(path);
            }
        }

        private void panelContraseña_Paint(object sender, PaintEventArgs e)
        {
            Panel p = sender as Panel;
            using (GraphicsPath path = RedondearRectangulo(p.ClientRectangle, 20))
            {
                p.Region = new Region(path);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
    }
}
