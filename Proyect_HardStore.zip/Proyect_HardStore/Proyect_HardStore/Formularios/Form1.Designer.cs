﻿namespace Proyect_HardStore
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnInciar = new System.Windows.Forms.Button();
            this.rbtnJefe = new System.Windows.Forms.RadioButton();
            this.rbtnTrabajador = new System.Windows.Forms.RadioButton();
            this.lbErrorUsuario = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbErroContraseña = new System.Windows.Forms.Label();
            this.lbCerrar = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtContraseña = new System.Windows.Forms.TextBox();
            this.PanelLogin = new System.Windows.Forms.Panel();
            this.PanelButon = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.PanelLogin.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtUsuario
            // 
            this.txtUsuario.BackColor = System.Drawing.Color.White;
            this.txtUsuario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUsuario.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuario.Location = new System.Drawing.Point(556, 192);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(182, 27);
            this.txtUsuario.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(461, 195);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Usuario:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(461, 269);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Contraseña:";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.AutoSize = true;
            this.btnRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnRegistrar.Location = new System.Drawing.Point(587, 488);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(82, 16);
            this.btnRegistrar.TabIndex = 4;
            this.btnRegistrar.Text = "registrarse";
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Swis721 Blk BT", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(41, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(225, 45);
            this.label4.TabIndex = 5;
            this.label4.Text = "HardStore";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(97, 254);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(218, 76);
            this.label5.TabIndex = 6;
            this.label5.Text = "Almacén \r\nde herramientas\r\n";
            // 
            // btnInciar
            // 
            this.btnInciar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btnInciar.FlatAppearance.BorderSize = 0;
            this.btnInciar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInciar.ForeColor = System.Drawing.Color.White;
            this.btnInciar.Location = new System.Drawing.Point(515, 430);
            this.btnInciar.Name = "btnInciar";
            this.btnInciar.Size = new System.Drawing.Size(223, 38);
            this.btnInciar.TabIndex = 7;
            this.btnInciar.Text = "Inciar sesión ";
            this.btnInciar.UseVisualStyleBackColor = false;
            this.btnInciar.Click += new System.EventHandler(this.btnInciar_Click);
            // 
            // rbtnJefe
            // 
            this.rbtnJefe.AutoSize = true;
            this.rbtnJefe.ForeColor = System.Drawing.Color.Navy;
            this.rbtnJefe.Location = new System.Drawing.Point(665, 358);
            this.rbtnJefe.Name = "rbtnJefe";
            this.rbtnJefe.Size = new System.Drawing.Size(54, 20);
            this.rbtnJefe.TabIndex = 9;
            this.rbtnJefe.TabStop = true;
            this.rbtnJefe.Text = "Jefe";
            this.rbtnJefe.UseVisualStyleBackColor = true;
            // 
            // rbtnTrabajador
            // 
            this.rbtnTrabajador.AutoSize = true;
            this.rbtnTrabajador.ForeColor = System.Drawing.Color.Navy;
            this.rbtnTrabajador.Location = new System.Drawing.Point(526, 358);
            this.rbtnTrabajador.Name = "rbtnTrabajador";
            this.rbtnTrabajador.Size = new System.Drawing.Size(96, 20);
            this.rbtnTrabajador.TabIndex = 10;
            this.rbtnTrabajador.TabStop = true;
            this.rbtnTrabajador.Text = "Trabajador";
            this.rbtnTrabajador.UseVisualStyleBackColor = true;
            // 
            // lbErrorUsuario
            // 
            this.lbErrorUsuario.AutoSize = true;
            this.lbErrorUsuario.Font = new System.Drawing.Font("Microsoft Yi Baiti", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErrorUsuario.ForeColor = System.Drawing.Color.Red;
            this.lbErrorUsuario.Location = new System.Drawing.Point(217, 222);
            this.lbErrorUsuario.Name = "lbErrorUsuario";
            this.lbErrorUsuario.Size = new System.Drawing.Size(110, 13);
            this.lbErrorUsuario.TabIndex = 11;
            this.lbErrorUsuario.Text = "USUARIO ERRONEO";
            this.lbErrorUsuario.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 16);
            this.label6.TabIndex = 12;
            // 
            // lbErroContraseña
            // 
            this.lbErroContraseña.AutoSize = true;
            this.lbErroContraseña.Font = new System.Drawing.Font("Microsoft Yi Baiti", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErroContraseña.ForeColor = System.Drawing.Color.Red;
            this.lbErroContraseña.Location = new System.Drawing.Point(587, 296);
            this.lbErroContraseña.Name = "lbErroContraseña";
            this.lbErroContraseña.Size = new System.Drawing.Size(133, 13);
            this.lbErroContraseña.TabIndex = 13;
            this.lbErroContraseña.Text = "CONTRASEÑA ERRONEA";
            this.lbErroContraseña.Visible = false;
            // 
            // lbCerrar
            // 
            this.lbCerrar.AutoSize = true;
            this.lbCerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCerrar.Location = new System.Drawing.Point(435, 0);
            this.lbCerrar.Name = "lbCerrar";
            this.lbCerrar.Size = new System.Drawing.Size(27, 25);
            this.lbCerrar.TabIndex = 15;
            this.lbCerrar.Text = "X";
            this.lbCerrar.Click += new System.EventHandler(this.lbCerrar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyect_HardStore.Properties.Resources.png_transparent_computer_icons_user_profile_avatar_avatar_heroes_monochrome_black_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(574, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(146, 137);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox2.Image = global::Proyect_HardStore.Properties.Resources._6938854_3402393;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(411, 526);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            this.pictureBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseDown);
            // 
            // txtContraseña
            // 
            this.txtContraseña.BackColor = System.Drawing.Color.White;
            this.txtContraseña.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtContraseña.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContraseña.Location = new System.Drawing.Point(556, 266);
            this.txtContraseña.Name = "txtContraseña";
            this.txtContraseña.Size = new System.Drawing.Size(182, 27);
            this.txtContraseña.TabIndex = 2;
            this.txtContraseña.TextChanged += new System.EventHandler(this.txtContraseña_TextChanged);
            // 
            // PanelLogin
            // 
            this.PanelLogin.Controls.Add(this.lbCerrar);
            this.PanelLogin.Controls.Add(this.PanelButon);
            this.PanelLogin.Controls.Add(this.lbErrorUsuario);
            this.PanelLogin.Dock = System.Windows.Forms.DockStyle.Right;
            this.PanelLogin.Location = new System.Drawing.Point(411, 0);
            this.PanelLogin.Name = "PanelLogin";
            this.PanelLogin.Size = new System.Drawing.Size(462, 526);
            this.PanelLogin.TabIndex = 16;
            // 
            // PanelButon
            // 
            this.PanelButon.Location = new System.Drawing.Point(115, 480);
            this.PanelButon.Name = "PanelButon";
            this.PanelButon.Size = new System.Drawing.Size(200, 30);
            this.PanelButon.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 526);
            this.Controls.Add(this.txtUsuario);
            this.Controls.Add(this.txtContraseña);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbErroContraseña);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rbtnTrabajador);
            this.Controls.Add(this.rbtnJefe);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnInciar);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.PanelLogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.PanelLogin.ResumeLayout(false);
            this.PanelLogin.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label btnRegistrar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnInciar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton rbtnJefe;
        private System.Windows.Forms.RadioButton rbtnTrabajador;
        private System.Windows.Forms.Label lbErrorUsuario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbErroContraseña;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbCerrar;
        private System.Windows.Forms.TextBox txtContraseña;
        private System.Windows.Forms.Panel PanelLogin;
        private System.Windows.Forms.Panel PanelButon;
    }
}

