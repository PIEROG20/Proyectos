﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Proyect_HardStore
{
    public partial class Form_Compra : Form
    {
        private atencion_cliente formPrincipal;
       
        public Form_Compra(atencion_cliente Fomrprincipal)
        {
            InitializeComponent();
            formPrincipal = Fomrprincipal;
        }

        // FINALIZAR PEDIDO
        private void btnFinalizar_Click(object sender, EventArgs e)
        {

            if (ValidarDatos())
            {
                string rutaProductos = Path.Combine(System.Windows.Forms.Application.StartupPath, "productos.csv");


                string direccion;
                string referencia;
                string distrito ;
                int preciEnvio;

                if (!rbtnDomicilio.Checked)
                {
                     direccion = "|-----|";
                     referencia = "|-----|";
                     distrito = "|-----|";
                     preciEnvio = 0;
                }
                else
                {
                     direccion = txtDirreccion.Text;
                     referencia = txtReferencia.Text;
                     distrito = txtDistrito.Text;
                     preciEnvio = 5;
                }

                string tipoEntrega = "";

                if (rbtnTienda.Checked)
                {
                    tipoEntrega = "En tienda";
                }
                else if (rbtnDomicilio.Checked)
                {
                    tipoEntrega = "A domicilio";
                }
                else
                {
                    MessageBox.Show("Seleccione un tipo de entrega.");
                    return; 
                }

                if (DatosGlobales.Productos.Count == 0)
                {
                    MessageBox.Show("Agrega al menos un producto.");
                    return;
                }

                // CREA UN NUEVO PEDIDO 
                PedidoUsuario nuevoPedido = new PedidoUsuario
                {
                    IDpedido = GenerarIDPedido(DatosGlobales.ArbolGeneral),
                    NombreAppellidos = txtNombresApellidos.Text,
                    Telefono = int.Parse(txtTelefono.Text),
                    DNI = int.Parse(txtDNI.Text),
                    Ticket = lbTicket.Text,
                    MetodoPago = cbMetodoPago.Text,
                    TipoEntrega = tipoEntrega,
                    FechaPedido = DateTime.Now,
                    Direccion = direccion,
                    Referencia = referencia,
                    Distrito = distrito,
                    PrecioEnvio = preciEnvio,
                };

                // Pasar los productos del carrito al pedido
                nuevoPedido.ListaProductos = DatosGlobales.Productos.ToList();



                // Insertar al árbol
                DatosGlobales.ArbolGeneral.Insertar(nuevoPedido);

                // Guardar en CSV
                DatosGlobales.ArbolGeneral.GuardarCSV("Pedidos.csv");

                ActualizarStockDesdeCarrito(rutaProductos);

                // Limpiar carrito
                DatosGlobales.LimpiarProductos();

                MessageBox.Show("Pedido guardado con éxito.");

                // volver a anterios formulario 
                formPrincipal.AtenderPedido();
                formPrincipal.MostrarAtendidos();
                formPrincipal.MostraEspera();
                this.Close();
            }
            else
            {
                ValidarDatos();
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtProducto.Text))
            {
                lbErrorProducto.Visible = true;
            }
            else { lbErrorProducto.Visible = false; }

            if (!int.TryParse(txtCantidad.Text, out int cantidad))
            {
                lbErrorCantidad.Visible = true;

            }
            else { lbErrorCantidad.Visible = false; }

            if (!double.TryParse(lbPrecioUnitario.Text, out double PrecioUNI))
            {
                MessageBox.Show("Ingrese el código del producto y la cantidad pedida ");
                return;
            }

            var producto = new PedidoProducto
            {
                Producto = txtProducto.Text,
                Codigo = txtCodigo.Text,
                CantidadPedida = int.Parse(txtCantidad.Text),
                PrecioUNI = double.Parse(lbPrecioUnitario.Text),
                PrecioTL = cantidad * PrecioUNI
            };

            DatosGlobales.Productos.Add(producto);

            // Mostrarlo 
            dtgvPedidos.Rows.Add(
                producto.Producto,
                producto.Codigo,
                producto.CantidadPedida,
                producto.PrecioUNI,
                producto.PrecioTL
            );

            // Limpiar solo las cajas de producto
            txtProducto.Clear();
            txtCodigo.Clear();
            txtCantidad.Clear();
            lbPrecioUnitario.Text = "";
            lbPrecioTotal.Text = "";
        }

        private void Form_Compra_Load(object sender, EventArgs e)
        {
            // obtener el ticket del primer cliente a atender 
            ClienteA primero = ColaClientes.Primero();
            if (primero == null)
            {
                MessageBox.Show("No hay clientes en la cola.");
                return;
            }
            lbTicket.Text = primero.Ticket;
            GbxDatosEnvio.Visible = false;  
            ErroresInvisible();

            // agrega columnas al dtgv 
            dtgvPedidos.Columns.Add("Producto", "Producto");
            dtgvPedidos.Columns.Add("Codigo", "Código");
            dtgvPedidos.Columns.Add("CantidadPedida", "Cantidad");
            dtgvPedidos.Columns.Add("PrecioUNI", "Precio Unitario");
            dtgvPedidos.Columns.Add("PrecioTL", "Precio Total");

            DatosGlobales.ArbolGeneral.CargarDesdeCSV("Pedidos.csv");
        }

        // CANCELAR PEDIDO 
        private void btnCancelar_Click(object sender, EventArgs e)
        {

            formPrincipal.AtenderPedido();
            formPrincipal.MostraEspera();
            formPrincipal.MostrarAtendidos();

            MessageBox.Show("pedido cancelado, pero atendido :)");
            this.Hide();
        }

        // MUESTRA O NO LAS DATOS DE ENVIO 
        private void rbtnTienda_CheckedChanged(object sender, EventArgs e)
        {
            GbxDatosEnvio.Visible = false;
        }

        private void rbtnDomicilio_CheckedChanged(object sender, EventArgs e)
        {
            GbxDatosEnvio.Visible = true;
        }


        // EJECUTA ALGORITMOBUSQUEDA EN UN EVENTO 
        private void txtCodigo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;  // Evita beep o salto de línea
                AlgoritmoBusqueda();
            }
        }


        // MUESTRA EL MOTO TOTAL 
        public void AlgoritmoBusqueda()
        {
            string codigo = txtCodigo.Text.Trim();

            if (string.IsNullOrEmpty(codigo))
            {
                MessageBox.Show("Ingrese un código.");
                return;
            }

            ListaEnlazadaP Products = new ListaEnlazadaP();
            Products.CargarDesdeCSV("productos.csv");

            Producto encontrado = Products.BuscarPorId(codigo);



            if (encontrado != null)
            {
                // datos del producto buscado
                string nombre = encontrado.Nombre;
                double precioUnitario = encontrado.Precio;
                int CantidadE = encontrado.Cantidad;

                // mostrar en el formulario 
                txtProducto.Text = nombre;
                lbPrecioUnitario.Text = precioUnitario.ToString();

                // calcula en precio total y lo muestra
                int CantidadP;
                if (!int.TryParse(txtCantidad.Text.Trim(), out CantidadP))
                {
                    MessageBox.Show("Ingrese una cantidad válida.");
                    return;
                }
                double total = CantidadP * precioUnitario;
                lbPrecioTotal.Text = total.ToString("0.00");

            }
            else
            {
                MessageBox.Show("Producto no encontrado.");
                txtProducto.Text = "-----";
                lbPrecioUnitario.Text = "----";
                return;
            }

        }
        
        // OTRAS FUNCIOENS 
        public void LimpiarCampos()
        {
            txtNombresApellidos.Clear();
            txtTelefono.Clear();
            txtDNI.Clear();
            txtProducto.Clear();
            txtCodigo.Clear();
            txtCantidad.Clear();
            txtCantidad.Clear();
            cbMetodoPago.SelectedIndex = -1;

            txtDirreccion.Clear();
            txtReferencia.Clear();
            txtDistrito.Clear();
        }

        public void ErroresInvisible()
        {
            lbErrorNombre.Visible = false;
            lbErrorTelefono.Visible = false;
            lbErrorDNI.Visible = false;
            lbErrorProducto.Visible = false;
            lbErrorCodigo.Visible = false;
            lbErrorCantidad.Visible = false;
            lbErrorMetodo.Visible = false;
            lbErrorEntrega.Visible = false;
            lbErrorDireccion.Visible = false;
            lbErrorReferencia.Visible = false;
            lbErrorDistrito.Visible = false;
        }

        private bool ValidarDatos()
        {
            bool valido = true;

            if (string.IsNullOrWhiteSpace(txtNombresApellidos.Text))
            { 
               lbErrorNombre.Visible = true;
                valido = false;
            }
            else {
                lbErrorNombre.Visible = false;
            }

            if (!int.TryParse(txtTelefono.Text, out int numero) || txtTelefono.Text.Length != 9)
            {
                lbErrorTelefono.Visible = true;
                valido = false;
            }
            else
            {
                lbErrorTelefono.Visible = false;
            }

            if (!int.TryParse(txtDNI.Text, out int dni) || txtDNI.Text.Length != 8)
            {
                lbErrorDNI.Visible = true;
                valido = false;
            }
            else {
                lbErrorDNI.Visible = false;
            }

            if (cbMetodoPago.SelectedIndex == -1)
            {
                lbErrorMetodo.Visible = true;
                valido = false;
            }
            else {
                lbErrorMetodo.Visible = false;
            }

            if (!rbtnDomicilio.Checked && !rbtnTienda.Checked)
            {
                lbErrorEntrega.Visible = true;
                valido = false;
            }
            else {
                lbErrorEntrega.Visible = false;
            }

            if (rbtnDomicilio.Checked)
            {
                // Direccion
                if (string.IsNullOrWhiteSpace(txtDirreccion.Text))
                {
                    lbErrorDireccion.Visible = true;
                    valido = false;
                }
                else {
                    lbErrorDireccion.Visible = false;
                }


                // Distrito
                if (string.IsNullOrWhiteSpace(txtDistrito.Text))
                {
                    lbErrorDistrito.Visible = true;
                    valido = false;
                }
                else {
                    lbErrorDistrito.Visible = false;
                }


                // Referencia
                if (string.IsNullOrWhiteSpace(txtReferencia.Text))
                {
                    lbErrorReferencia.Visible = true;
                    valido = false;
                }
                else {
                    lbErrorReferencia.Visible = false;
                }
               
            }
            else
            {
                // Si se selecciona TIENDA, ocultar errores de domicilio
                lbErrorDireccion.Visible = false;
                lbErrorDistrito.Visible = false;
                lbErrorReferencia.Visible = false;
            }
            return valido;
        }

        public static int GenerarIDPedido(ArbolBinario arbol)
        {
            Random rnd = new Random();
            int id;

            do
            {
                id = rnd.Next(10000000, 99999999);
            }
            while (arbol.BuscarPorID(id) != null); // si existe, genera otro

            return id;
        }

        public static void ActualizarStockDesdeCarrito(string rutaCSV)
        {
            // 1. Leer todos los productos desde el archivo CSV
            var lineas = File.ReadAllLines(rutaCSV).ToList();

            // Saltamos la cabecera
            var cabecera = lineas[0];
            var filas = lineas.Skip(1).ToList();

            // Convertir CSV → lista de productos reales
            List<Producto> productosArchivo = new List<Producto>();

            foreach (var linea in filas)
            {
                var d = linea.Split(',');

                productosArchivo.Add(new Producto
                {
                    Codigo = d[0],
                    Nombre = d[1],
                    Cantidad = int.Parse(d[2]),
                    Proveedor = d[3],
                    Precio = double.Parse(d[4]),
                    Unidad = d[5],
                    Categoria = d[6],
                    FechaRegistro = DateTime.Parse(d[7])
                });
            }

            // 2. Aplicar los cambios según el carrito
            foreach (var itemCarrito in DatosGlobales.Productos)
            {
                var prod = productosArchivo.FirstOrDefault(p => p.Codigo == itemCarrito.Codigo);

                if (prod != null)
                {
                    prod.Cantidad -= itemCarrito.CantidadPedida;

                    if (prod.Cantidad < 0)
                        prod.Cantidad = 0; // evita stock negativo
                }
            }

            // 3. Guardar nuevamente en el CSV
            using (StreamWriter sw = new StreamWriter(rutaCSV))
            {
                sw.WriteLine(cabecera); // cabecera original

                foreach (var p in productosArchivo)
                {
                    sw.WriteLine($"{p.Codigo},{p.Nombre},{p.Cantidad},{p.Proveedor},{p.Precio},{p.Unidad},{p.Categoria},{p.FechaRegistro}");
                }
            }
        }

        private void btnBoleta_Click(object sender, EventArgs e)
        {
            // Asegurarse que el usuario haya ingresado los datos necesarios y tenga productos en el carrito
            if (!ValidarDatos())
            {
                MessageBox.Show("Complete los datos obligatorios antes de imprimir la boleta.", "Datos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (DatosGlobales.Productos == null || DatosGlobales.Productos.Count == 0)
            {
                MessageBox.Show("Agrega al menos un producto antes de imprimir la boleta.", "Carrito vacío", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            PrintDocument pd = new PrintDocument();
            pd.PrintPage += (s, ev) =>
            {
                var sb = new StringBuilder();

                // Header
                sb.AppendLine("--------------- HARDSTORE ---------------");
                sb.AppendLine("Dirección: Av. Principal 123 - Ciudad");
                sb.AppendLine("Tel: 999-888-777");
                sb.AppendLine("RUC: 12345678901");
                sb.AppendLine("-----------------------------------------");
                sb.AppendLine();

                // Cliente info (usar los datos que el usuario ingresó en el formulario)
                string cliente = txtNombresApellidos.Text.Trim();
                string dni = txtDNI.Text.Trim();
                string telefono = txtTelefono.Text.Trim();
                string ticket = lbTicket.Text.Trim();
                sb.AppendLine($"Cliente: {cliente}");
                sb.AppendLine($"DNI: {dni}");
                sb.AppendLine($"Teléfono: {telefono}");
                sb.AppendLine($"Ticket Nº: {ticket}");
                sb.AppendLine();

                // Pedido meta
                string tipoAtencion = "Compra";
                string tipoEntrega = rbtnTienda.Checked ? "Retiro en tienda" : (rbtnDomicilio.Checked ? "A domicilio" : "-");
                string metodoPago = !string.IsNullOrWhiteSpace(cbMetodoPago.Text) ? cbMetodoPago.Text : "-";
                string fecha = DateTime.Now.ToString("dd/MM/yyyy HH:mm");

                sb.AppendLine($"Tipo de atención: {tipoAtencion}");
                sb.AppendLine($"Tipo de entrega: {tipoEntrega}");
                sb.AppendLine($"Método de pago: {metodoPago}");
                sb.AppendLine($"Fecha: {fecha}");
                sb.AppendLine();
                sb.AppendLine("-----------------------------------------");

                // Products header (aligned)
                // Columns: Producto (30), Cant. (6), P.Unit (9), Subt. (9)
                sb.AppendFormat("{0,-30}{1,6}{2,9}{3,9}\n", "Producto", "Cant.", "P.Unit", "Subt.");

                double subtotal = 0.0;
                foreach (var p in DatosGlobales.Productos)
                {
                    string nombre = p.Producto ?? "";
                    if (nombre.Length > 30) nombre = nombre.Substring(0, 30);
                    int cant = p.CantidadPedida;
                    double pu = p.PrecioUNI;
                    double sub = p.PrecioTL;
                    subtotal += sub;

                    sb.AppendFormat("{0,-30}{1,6}{2,9}{3,9}\n",
                        nombre,
                        cant,
                        pu.ToString("0.00"),
                        sub.ToString("0.00"));
                }

                sb.AppendLine("-----------------------------------------");

                double igv = Math.Round(subtotal * 0.18, 2);
                double total = Math.Round(subtotal + igv, 2);

                // If delivery price applies, add it to total and show
                double precioEnvio = rbtnDomicilio.Checked ? 5.0 : 0.0;
                if (precioEnvio > 0)
                {
                    sb.AppendFormat("{0,35}{1,9}\n", "Envío:", precioEnvio.ToString("0.00"));
                    total = Math.Round(total + precioEnvio, 2);
                }

                sb.AppendFormat("{0,35}{1,9}\n", "Subtotal:", subtotal.ToString("0.00"));
                sb.AppendFormat("{0,35}{1,9}\n", "IGV (18%):", igv.ToString("0.00"));
                sb.AppendFormat("{0,35}{1,9}\n", "TOTAL:", total.ToString("0.00"));
                sb.AppendLine("-----------------------------------------");
                sb.AppendLine("Gracias por su compra!");
                sb.AppendLine("Hardstore © " + DateTime.Now.Year);

                // Draw using monospace font to preserve alignment
                var font = new Font("Consolas", 10);
                ev.Graphics.DrawString(sb.ToString(), font, Brushes.Black, new PointF(40, 40));
            };

            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = pd;

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                pd.Print();
            }
        }

    }
}