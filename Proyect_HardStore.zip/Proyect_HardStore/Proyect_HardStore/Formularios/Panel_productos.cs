﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    public partial class Panel_productos : Form
    {
        ListaEnlazadaP listP = DatosGlobales.listP;
        public Panel_productos()
        {
            InitializeComponent();
        }

        // AGREGAR PRODUCTO 
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // VALIDACIONES
            if (string.IsNullOrWhiteSpace(txtCodigo.Text) || string.IsNullOrWhiteSpace(txtProducto.Text) || string.IsNullOrWhiteSpace(txtProveedor.Text) || string.IsNullOrWhiteSpace(txtUnidad.Text))
            {
                MessageBox.Show("Por favor, ingrese todos los datos requeridos");
                return;
            }
            if (cbxCategoria.SelectedIndex == -1)
            {
                MessageBox.Show("Debes seleccionar una categoría");
                return;
            }
            if (!double.TryParse(txtPrecio.Text, out double precio) || precio < 0 )
            {
                MessageBox.Show("Ingrese un precio adecuado");
                return;
            }

            if (!int.TryParse(txtCantidad.Text, out int cantidad) || cantidad < 0)
            {
                MessageBox.Show("Ingreses una cantidad valida");
                return;
            }

            // Crea un instancia nuevo y la guarda 
            Producto nuevoProducto = new Producto
            {
                Codigo = txtCodigo.Text,
                Nombre = txtProducto.Text,
                Proveedor = txtProveedor.Text,
                Unidad = txtUnidad.Text,
                Precio = precio,
                Cantidad = cantidad,
                Categoria = cbxCategoria.SelectedItem.ToString(),
                FechaRegistro = DateTime.Now
            };
            listP.Agregar(nuevoProducto);
            listP.GuardarCSV("productos.csv");

            Mostrar();
            VaciarCampos();

        }

        // ELIMINAR UNA CANTIDAD DETERNIADA DE UN PRODUCTO 
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodigo.Text) || string.IsNullOrWhiteSpace(txtCantidad.Text))
            {
                MessageBox.Show("Ingrese porfavor , el codigo y la cantidad que desea eliminar");
                return;
            }

            if (!int.TryParse(txtCantidad.Text, out int cantidad) || cantidad < 0)
            {
                MessageBox.Show("Por favor ingrese una cantidad valida ");
                return;
            }

            DialogResult mensaje = MessageBox.Show(
                "¿Estás seguro de que deseas eliminar esta Herramienta del inventario ?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo);

            string codigo = txtCodigo.Text;
            

            bool resultado = DatosGlobales.listP.EliminarCantidad(codigo, cantidad);

            if (mensaje == DialogResult.Yes)
            {
                if (resultado)
                {
                    MessageBox.Show("Cantidad eliminada correctamente.");

                    dtgvProductos.DataSource = null;
                    dtgvProductos.DataSource = DatosGlobales.listP.ConvertirALista();

                    listP.GuardarCSV("productos.csv");
                }
                else
                    MessageBox.Show("Código no encontrado o cantidad insuficiente.");
                VaciarCampos();
            }
            else
            {
                MessageBox.Show("Operación cancelada.", "Cancelado");
            }
        }

        // BUSCA UN PRODUCTO
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodigo.Text))
            {
                MessageBox.Show("Por favor ingrese el códgio de la herramienta a buscar");
                return;

            }
            string Codigo = txtCodigo.Text;
            var Pro = DatosGlobales.listP.BuscarPorId(Codigo);

            if (Pro != null)
            {
                dtgvProductos.DataSource = new List<Producto> { Pro };

            }
            else
            {
                MessageBox.Show("No se encontró ninguna herrmienta con ese código.");
                Mostrar();
            }
        }

        // MUESTRA LOS PRODUCTO EN EL DTGV
        public void Mostrar()
        {
            string ruta = Path.Combine(Application.StartupPath, "productos.csv");
            DatosGlobales.listP.CargarDesdeCSV(ruta);
            dtgvProductos.DataSource = null;
            dtgvProductos.DataSource = DatosGlobales.listP.ConvertirALista();
        }

        private void Panel_productos_Load(object sender, EventArgs e)
        {  
            Mostrar();
        }

       

        // LIMPIA TEXBOX
        public void VaciarCampos()
        {
            txtCantidad.Clear();
            txtCodigo.Clear();
            txtPrecio.Clear();
            txtProducto.Clear();
            txtProveedor.Clear();
            txtUnidad.Clear();
            cbxCategoria.SelectedIndex = -1;
        }

    


        // PASA LOS DATOS DEL DTGV A LOS TEXBOX 
        private void dtgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            // Obtener la fila seleccionada
            DataGridViewRow fila = dtgvProductos.Rows[e.RowIndex];

            txtCodigo.Text = fila.Cells["Codigo"].Value?.ToString();
            txtProducto.Text = fila.Cells["Nombre"].Value?.ToString();
            txtProveedor.Text = fila.Cells["Proveedor"].Value?.ToString();
            txtUnidad.Text = fila.Cells["Unidad"].Value?.ToString();
            txtCantidad.Text = fila.Cells["Cantidad"].Value?.ToString();
            txtPrecio.Text = fila.Cells["Precio"].Value?.ToString();
            cbxCategoria.Text = fila.Cells["Categoria"].Value?.ToString();
        }

        // CAMBIA EL FORMATO DE LA FECHA 
        private void dtgvProductos_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dtgvProductos.Columns[e.ColumnIndex].Name == "FechaRegistro" && e.Value is DateTime fecha)
            {
                e.Value = fecha.ToString("yyyy-MM-dd"); // solo año, mes, día
                e.FormattingApplied = true;
            }
            
        }

        
    }
}
