﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    public partial class Operaciones : Form
    {
        // Pila para almacenar operaciones
        private Stack<string> pilaOperaciones = new Stack<string>();
        public Operaciones()
        {
            InitializeComponent();
            // Inicializar el log reciente al cargar el formulario
            actualizarLogReciente(null, EventArgs.Empty);
        }

        private void btnregistraroperacion_Click(object sender, EventArgs e)
        {
            string operacion = txtoperacionactual.Text.Trim();
            // Leer la descripción desde el TextBox correcto
            string descripcion = txtdescripcion.Text.Trim();

            if (string.IsNullOrEmpty(operacion))
            {
                MessageBox.Show("Ingrese una operación válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string registro = $"{DateTime.Now:dd/MM/yyyy HH:mm:ss} - {operacion}: {descripcion}";
            pilaOperaciones.Push(registro);

            // Actualizar historial visual
            listBoxhistorialoperaciones.Items.Insert(0, registro); // Insertar al inicio
            txtoperacionactual.Clear();
            txtdescripcion.Clear();

            // Actualizar el textbox de log reciente mostrando múltiples entradas (todas las operaciones recientes)
            txtlogreciente.Text = GetLogText();
        }

        private void btndeshacerultima_Click(object sender, EventArgs e)
        {
            if (pilaOperaciones.Count > 0)
            {
                string ultima = pilaOperaciones.Pop();
                listBoxhistorialoperaciones.Items.Remove(ultima);

                // Actualizar el textbox de log reciente después de deshacer
                txtlogreciente.Text = GetLogText();
            }
            else
            {
                MessageBox.Show("No hay operaciones para deshacer.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void actualizarLogReciente(object sender, EventArgs e)
        {
            txtlogreciente.Text = GetLogText();
        }

        // Construye el texto para el textbox de log reciente mostrando todas las entradas (más recientes primero)
        private string GetLogText()
        {
            if (pilaOperaciones.Count == 0)
                return "Sin operaciones recientes.";

            // Enumeración de Stack devuelve los elementos en orden LIFO (más reciente primero)
            return string.Join(Environment.NewLine + Environment.NewLine, pilaOperaciones);
        }

    }
}
