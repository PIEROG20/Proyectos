﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    public partial class atencion_cliente : Form
    {
        public atencion_cliente()
        {
            InitializeComponent();
            
        }


        // AGREGAR UN CLIENTE A LA COLA
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string usuario = txtCliente.Text.Trim();
           

            // validaciones
            if (string.IsNullOrEmpty(usuario))
            {
                lbErrorCliente.Visible = true;
                return;
            }
            else 
            {
                lbErrorCliente.Visible = false;
                
            }


                // Agrega a la cola 
            ColaClientes.Encolar(usuario);
            MostraEspera();

            txtCliente.Clear();
           

        }

        // ATENDER AL PRIMERO EN LA COLA 
        private void btnatenderpedido_Click(object sender, EventArgs e)
        {
            if (ColaClientes.ObtenerCola().Count == 0)
            {
                MessageBox.Show("No ha cliente en la cola");
                return;
            }
            Form_Compra ventana = new Form_Compra(this);
            ventana.ShowDialog();

        }

        // DESENCOLA AL CLIENTE 
        private void btncancelarpedido_Click(object sender, EventArgs e)
        {
            if (ColaClientes.ObtenerCola().Count == 0)
            {
                MessageBox.Show("No ha cliente en la cola");
                
            }
             ColaClientes.CancelarAtencion();
            MostraEspera();
          
        }

        // IMPRIME EL TICKET 
        private void btnimprimir_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += (s, ev) =>
            {
                string cliente = txtCliente.Text;
                string tipoAtencion = " Compra ";
                string fecha = DateTime.Now.ToString("dd/MM/yyyy HH:mm");

                string contenido = $"--- TICKET HARDSTORE ---\nCliente: {cliente}\nTipo de atención: {tipoAtencion}\nFecha: {fecha}\n------------------------";

                ev.Graphics.DrawString(contenido, new Font("Arial", 12), Brushes.Black, new PointF(100, 100));
            };

            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = pd;

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                pd.Print();
            }
        }

        // otras funciones 
        private void atencion_cliente_Load(object sender, EventArgs e)
        {
            MostraEspera();
            MostrarAtendidos();
            lbErrorCliente.Visible = false;
           
        }

        public void AtenderPedido()
        {
            ColaClientes.Atender();
        }

        public void MostraEspera()
        {
            dgvEspera.DataSource = null;
            dgvEspera.DataSource = ColaClientes.ObtenerCola();
        }

        public void MostrarAtendidos()
        {
            dgvAtendidos.DataSource = null;
            dgvAtendidos.DataSource = ColaClientes.ObtenerAtendidos();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }


      
    }
}
        
    

    





