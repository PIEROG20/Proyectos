﻿using Proyect_HardStore.Estructura_de_datos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    public partial class Almacen : Form
    {
        GrafoAlmacen grafoAlmacen = GrafoAlmacen.CargarGrafo();
        public Almacen()
        {
            InitializeComponent();
        }
        List<int> rutadijst = null;
        List<int> rutabfs = null;
        private void btncalcularrutaoptima_Click(object sender, EventArgs e)
        {
            string destinoT = comboBoxfinRutasimple.Text;
            int destino = 0;
            if (destinoT =="Manuales")
            {
                destino = 1;
            }
            else if(destinoT =="Electricas")
            {
                destino = 2;
            }
            else if(destinoT =="Medición")
            {
                destino = 3;
            }
            else if(destinoT =="Neumatícas")
            {
                destino = 4;
            }
            else if(destinoT=="Industrial")
            {
                destino = 5;
            }
            else if(destinoT == "Soldadura")
            {
                destino= 6;
            }
            else if(destinoT =="Construcción")
            {
                destino = 7;
            }
            if (destino == 0)
            {
                return;
            }
            rutabfs = null;
            rutadijst = null;
            var Resiltado = grafoAlmacen.RutaCortaSinpesos(0,destino);
            
            rutabfs = Resiltado;
            DibujarGrafo(grafoAlmacen,pictureBoxvisualizaciondelmapa);
        }
        

        private void buttonRecorridomulti_Click(object sender, EventArgs e)
        {
            rutabfs = null;
            rutadijst = null;
            if (listBoxRuta.Items.Count == 0)
            {
                MessageBox.Show("esta vacio no puede proceder");
                return;
            }
            var listaC = grafoAlmacen.ConvertiraNum(listBoxRuta);
            var Rutaop = grafoAlmacen.RutaMultidestino(0,listaC);
            rutadijst = Rutaop.ruta;
            DibujarGrafo(grafoAlmacen, pictureBoxvisualizaciondelmapa);

        }

        private void btnAgregaraList_Click(object sender, EventArgs e)
        {
            if(comboBoxRutaAlista.SelectedItem == null)
            {
                MessageBox.Show("Seleccione un elemento xf");
                return;
            }
            string text = comboBoxRutaAlista.SelectedItem.ToString();
            if(!listBoxRuta.Items.Contains(text))
            {
                listBoxRuta.Items.Add(text);
            }
            else
            {
                MessageBox.Show("elemento existente");
            }
        }
        public void DibujarGrafo(GrafoAlmacen g, PictureBox pb)
        {
            Bitmap bmp = new Bitmap(pb.Width, pb.Height);
            Graphics gph = Graphics.FromImage(bmp);
            gph.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // ---------------- POSICIONES ----------------
            Point[] pos = new Point[]
            {
        new Point(350, 250), // 0
        new Point(100, 50),  // 1
        new Point(250, 50),  // 2
        new Point(400, 50),  // 3
        new Point(100, 150), // 4
        new Point(250, 150), // 5
        new Point(400, 150), // 6
        new Point(100, 250), // 7
        new Point(250, 250), // 8
            };
            Pen penNormal = new Pen(Color.Black, 2);
            Pen penDijkstra = new Pen(Color.Red, 4);
            Pen penBFS = new Pen(Color.Blue, 4);

            bool EsAristaEnRuta(List<int> ruta, int a, int b)
            {
                if (ruta == null) return false;
                for (int i = 0; i < ruta.Count - 1; i++)
                    if ((ruta[i] == a && ruta[i + 1] == b) ||
                        (ruta[i] == b && ruta[i + 1] == a))
                        return true;
                return false;
            }

            //ARISTAS
            for (int i = 0; i < g.CantidadNodo; i++)
            {
                for (int j = i + 1; j < g.CantidadNodo; j++)
                {
                    if (g.Matriz[i, j] != int.MaxValue && g.Matriz[i, j] != 0)
                    {
                        Pen p = penNormal;

                        // prioriza BFS si solo BFS está activo
                        if (EsAristaEnRuta(rutabfs, i, j))
                            p = penBFS;

                        // prioriza Dijkstra si también coincide
                        if (EsAristaEnRuta(rutadijst, i, j))
                            p = penDijkstra;

                        gph.DrawLine(p, pos[i], pos[j]);

                        // texto distancia
                        var mid = new Point((pos[i].X + pos[j].X) / 2,
                                            (pos[i].Y + pos[j].Y) / 2);

                        gph.DrawString(g.Matriz[i, j].ToString(),
                            new Font("Arial", 10),
                            Brushes.Black,
                            mid);
                    }
                }
            }

            //NODOS
            for (int i = 0; i < g.CantidadNodo; i++)
            {
                Rectangle r = new Rectangle(pos[i].X - 20, pos[i].Y - 20, 40, 40);
                gph.FillEllipse(Brushes.LightBlue, r);
                gph.DrawEllipse(Pens.DarkBlue, r);

                gph.DrawString(
                    $"{i}\n{g.Nodos[i].Nombre}\nP={g.Nodos[i].PesoPromedio}",
                    new Font("Arial", 8),
                    Brushes.Black,
                    pos[i].X - 20,
                    pos[i].Y - 35);
            }

            pb.Image = bmp;
        }

        private void Almacen_Load(object sender, EventArgs e)
        {
            DibujarGrafo(grafoAlmacen, pictureBoxvisualizaciondelmapa);
            
        }
    }
}
