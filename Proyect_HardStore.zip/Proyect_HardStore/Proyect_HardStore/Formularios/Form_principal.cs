﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Proyect_HardStore.Metodo_Forms;

namespace Proyect_HardStore
{
    public partial class Form_principal : Form
    {
        MetodoFormHijos Metodoform = new MetodoFormHijos();
        public Form_principal()
        {
            InitializeComponent();

        }

        // Nuevo constructor que recibe el nombre de usuario y actualiza la etiqueta de bienvenida
        public Form_principal(string nombreUsuario) : this()
        {
            if (!string.IsNullOrWhiteSpace(nombreUsuario))
            {
                label2.Text = $"Bienvenido {nombreUsuario}!";
            }
        }

        private void Form_principal_Load(object sender, EventArgs e)
        {

        }

        private void btnProducto_Click(object sender, EventArgs e)
        {
            Metodoform.abrirFormHijos(new Panel_productos(), sender, panelEscritorio, panelBotones);
        }

        private void llb_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void btnAtencion_Click(object sender, EventArgs e)
        {
            Metodoform.abrirFormHijos(new atencion_cliente(), sender, panelEscritorio, panelBotones);
        }

        private void btnAlmacen_Click(object sender, EventArgs e)
        {
            Metodoform.abrirFormHijos(new Almacen(), sender, panelEscritorio, panelBotones);
        }

        private void btnCuenta_Click(object sender, EventArgs e)
        {
            Metodoform.abrirFormHijos(new Form_Usuario(), sender, panelEscritorio, panelBotones);
        }

        private void btnoperaciones_Click(object sender, EventArgs e)
        {
            Metodoform.abrirFormHijos(new Operaciones(), sender, panelEscritorio, panelBotones);
        }
    }
}

