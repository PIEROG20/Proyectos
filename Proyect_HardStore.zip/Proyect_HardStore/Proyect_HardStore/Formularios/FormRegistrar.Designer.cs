﻿namespace Proyect_HardStore
{
    partial class FormRegistrar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDNI = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbErrorDNI = new System.Windows.Forms.Label();
            this.lbErroCorreo = new System.Windows.Forms.Label();
            this.lbErrorDireccion = new System.Windows.Forms.Label();
            this.lbErrorTelefono = new System.Windows.Forms.Label();
            this.lbErrorNombre = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCodigoT = new System.Windows.Forms.TextBox();
            this.txtContraseña = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnRegistrarse = new System.Windows.Forms.Button();
            this.rbtnJefe = new System.Windows.Forms.RadioButton();
            this.rbtnTrabajador = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbRegresar = new System.Windows.Forms.Label();
            this.panelButons = new System.Windows.Forms.Panel();
            this.PanelEscritorio2 = new System.Windows.Forms.Panel();
            this.lbErrorCargo = new System.Windows.Forms.Label();
            this.lbErrorContraseña = new System.Windows.Forms.Label();
            this.lbErrorUsuario = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panelButons.SuspendLayout();
            this.PanelEscritorio2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(20, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombres y apellidos:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(23, 54);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(217, 22);
            this.txtNombre.TabIndex = 1;
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(100, 102);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(143, 22);
            this.txtTelefono.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(20, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Telefono:";
            // 
            // txtDireccion
            // 
            this.txtDireccion.Location = new System.Drawing.Point(100, 146);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(143, 22);
            this.txtDireccion.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(20, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Dirrección:";
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(100, 191);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(143, 22);
            this.txtCorreo.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Navy;
            this.label4.Location = new System.Drawing.Point(20, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Correo:";
            // 
            // txtDNI
            // 
            this.txtDNI.Location = new System.Drawing.Point(72, 237);
            this.txtDNI.Name = "txtDNI";
            this.txtDNI.Size = new System.Drawing.Size(116, 22);
            this.txtDNI.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Navy;
            this.label5.Location = new System.Drawing.Point(20, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "DNI:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbErrorDNI);
            this.groupBox1.Controls.Add(this.lbErroCorreo);
            this.groupBox1.Controls.Add(this.lbErrorDireccion);
            this.groupBox1.Controls.Add(this.lbErrorTelefono);
            this.groupBox1.Controls.Add(this.lbErrorNombre);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtDNI);
            this.groupBox1.Controls.Add(this.txtNombre);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtCorreo);
            this.groupBox1.Controls.Add(this.txtTelefono);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtDireccion);
            this.groupBox1.Location = new System.Drawing.Point(26, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(295, 291);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos personales";
            // 
            // lbErrorDNI
            // 
            this.lbErrorDNI.AutoSize = true;
            this.lbErrorDNI.Font = new System.Drawing.Font("Microsoft Yi Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErrorDNI.ForeColor = System.Drawing.Color.Red;
            this.lbErrorDNI.Location = new System.Drawing.Point(112, 260);
            this.lbErrorDNI.Name = "lbErrorDNI";
            this.lbErrorDNI.Size = new System.Drawing.Size(76, 15);
            this.lbErrorDNI.TabIndex = 14;
            this.lbErrorDNI.Text = "Ingresar dato";
            // 
            // lbErroCorreo
            // 
            this.lbErroCorreo.AutoSize = true;
            this.lbErroCorreo.Font = new System.Drawing.Font("Microsoft Yi Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErroCorreo.ForeColor = System.Drawing.Color.Red;
            this.lbErroCorreo.Location = new System.Drawing.Point(164, 215);
            this.lbErroCorreo.Name = "lbErroCorreo";
            this.lbErroCorreo.Size = new System.Drawing.Size(76, 15);
            this.lbErroCorreo.TabIndex = 13;
            this.lbErroCorreo.Text = "Ingresar dato";
            // 
            // lbErrorDireccion
            // 
            this.lbErrorDireccion.AutoSize = true;
            this.lbErrorDireccion.Font = new System.Drawing.Font("Microsoft Yi Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErrorDireccion.ForeColor = System.Drawing.Color.Red;
            this.lbErrorDireccion.Location = new System.Drawing.Point(167, 170);
            this.lbErrorDireccion.Name = "lbErrorDireccion";
            this.lbErrorDireccion.Size = new System.Drawing.Size(76, 15);
            this.lbErrorDireccion.TabIndex = 12;
            this.lbErrorDireccion.Text = "Ingresar dato";
            // 
            // lbErrorTelefono
            // 
            this.lbErrorTelefono.AutoSize = true;
            this.lbErrorTelefono.Font = new System.Drawing.Font("Microsoft Yi Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErrorTelefono.ForeColor = System.Drawing.Color.Red;
            this.lbErrorTelefono.Location = new System.Drawing.Point(167, 126);
            this.lbErrorTelefono.Name = "lbErrorTelefono";
            this.lbErrorTelefono.Size = new System.Drawing.Size(76, 15);
            this.lbErrorTelefono.TabIndex = 11;
            this.lbErrorTelefono.Text = "Ingresar dato";
            // 
            // lbErrorNombre
            // 
            this.lbErrorNombre.AutoSize = true;
            this.lbErrorNombre.Font = new System.Drawing.Font("Microsoft Yi Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErrorNombre.ForeColor = System.Drawing.Color.Red;
            this.lbErrorNombre.Location = new System.Drawing.Point(164, 79);
            this.lbErrorNombre.Name = "lbErrorNombre";
            this.lbErrorNombre.Size = new System.Drawing.Size(76, 15);
            this.lbErrorNombre.TabIndex = 10;
            this.lbErrorNombre.Text = "Ingresar dato";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Navy;
            this.label6.Location = new System.Drawing.Point(63, 445);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Cargo:";
            // 
            // txtUsuario
            // 
            this.txtUsuario.Location = new System.Drawing.Point(127, 355);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(143, 22);
            this.txtUsuario.TabIndex = 16;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(116, 444);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(143, 22);
            this.txtCargo.TabIndex = 12;
            this.txtCargo.TextChanged += new System.EventHandler(this.txtCargo_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Navy;
            this.label7.Location = new System.Drawing.Point(41, 361);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 16);
            this.label7.TabIndex = 15;
            this.label7.Text = "Usuario:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(313, 361);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 16);
            this.label8.TabIndex = 13;
            this.label8.Text = "ID del usuario: ";
            // 
            // txtCodigoT
            // 
            this.txtCodigoT.Location = new System.Drawing.Point(316, 389);
            this.txtCodigoT.Name = "txtCodigoT";
            this.txtCodigoT.Size = new System.Drawing.Size(143, 22);
            this.txtCodigoT.TabIndex = 14;
            // 
            // txtContraseña
            // 
            this.txtContraseña.Location = new System.Drawing.Point(129, 401);
            this.txtContraseña.Name = "txtContraseña";
            this.txtContraseña.Size = new System.Drawing.Size(141, 22);
            this.txtContraseña.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Navy;
            this.label9.Location = new System.Drawing.Point(41, 404);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 16);
            this.label9.TabIndex = 17;
            this.label9.Text = "Contraseña:";
            // 
            // btnRegistrarse
            // 
            this.btnRegistrarse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btnRegistrarse.FlatAppearance.BorderSize = 0;
            this.btnRegistrarse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistrarse.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRegistrarse.Location = new System.Drawing.Point(147, 501);
            this.btnRegistrarse.Name = "btnRegistrarse";
            this.btnRegistrarse.Size = new System.Drawing.Size(174, 34);
            this.btnRegistrarse.TabIndex = 19;
            this.btnRegistrarse.Text = "Registrarse";
            this.btnRegistrarse.UseVisualStyleBackColor = false;
            this.btnRegistrarse.Click += new System.EventHandler(this.btnRegistrarse_Click);
            // 
            // rbtnJefe
            // 
            this.rbtnJefe.AutoSize = true;
            this.rbtnJefe.ForeColor = System.Drawing.Color.Navy;
            this.rbtnJefe.Location = new System.Drawing.Point(13, 85);
            this.rbtnJefe.Name = "rbtnJefe";
            this.rbtnJefe.Size = new System.Drawing.Size(54, 20);
            this.rbtnJefe.TabIndex = 20;
            this.rbtnJefe.TabStop = true;
            this.rbtnJefe.Text = "Jefe";
            this.rbtnJefe.UseVisualStyleBackColor = true;
            // 
            // rbtnTrabajador
            // 
            this.rbtnTrabajador.AutoSize = true;
            this.rbtnTrabajador.ForeColor = System.Drawing.Color.Navy;
            this.rbtnTrabajador.Location = new System.Drawing.Point(13, 47);
            this.rbtnTrabajador.Name = "rbtnTrabajador";
            this.rbtnTrabajador.Size = new System.Drawing.Size(96, 20);
            this.rbtnTrabajador.TabIndex = 21;
            this.rbtnTrabajador.TabStop = true;
            this.rbtnTrabajador.Text = "Trabajador";
            this.rbtnTrabajador.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbtnJefe);
            this.groupBox2.Controls.Add(this.rbtnTrabajador);
            this.groupBox2.Location = new System.Drawing.Point(376, 31);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(135, 211);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tipo de usuario:";
            // 
            // lbRegresar
            // 
            this.lbRegresar.AutoSize = true;
            this.lbRegresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRegresar.ForeColor = System.Drawing.Color.Navy;
            this.lbRegresar.Location = new System.Drawing.Point(35, 9);
            this.lbRegresar.Name = "lbRegresar";
            this.lbRegresar.Size = new System.Drawing.Size(138, 16);
            this.lbRegresar.TabIndex = 23;
            this.lbRegresar.Text = "¿Ya tienes cuenta?";
            this.lbRegresar.Click += new System.EventHandler(this.lbRegresar_Click);
            // 
            // panelButons
            // 
            this.panelButons.Controls.Add(this.lbRegresar);
            this.panelButons.Location = new System.Drawing.Point(134, 541);
            this.panelButons.Name = "panelButons";
            this.panelButons.Size = new System.Drawing.Size(200, 36);
            this.panelButons.TabIndex = 24;
            // 
            // PanelEscritorio2
            // 
            this.PanelEscritorio2.Controls.Add(this.label8);
            this.PanelEscritorio2.Controls.Add(this.groupBox2);
            this.PanelEscritorio2.Controls.Add(this.lbErrorCargo);
            this.PanelEscritorio2.Controls.Add(this.lbErrorContraseña);
            this.PanelEscritorio2.Controls.Add(this.txtCodigoT);
            this.PanelEscritorio2.Controls.Add(this.btnRegistrarse);
            this.PanelEscritorio2.Controls.Add(this.lbErrorUsuario);
            this.PanelEscritorio2.Controls.Add(this.panelButons);
            this.PanelEscritorio2.Controls.Add(this.txtCargo);
            this.PanelEscritorio2.Controls.Add(this.groupBox1);
            this.PanelEscritorio2.Controls.Add(this.txtContraseña);
            this.PanelEscritorio2.Controls.Add(this.label7);
            this.PanelEscritorio2.Controls.Add(this.label6);
            this.PanelEscritorio2.Controls.Add(this.label9);
            this.PanelEscritorio2.Controls.Add(this.txtUsuario);
            this.PanelEscritorio2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelEscritorio2.Location = new System.Drawing.Point(0, 0);
            this.PanelEscritorio2.Name = "PanelEscritorio2";
            this.PanelEscritorio2.Size = new System.Drawing.Size(539, 605);
            this.PanelEscritorio2.TabIndex = 25;
            // 
            // lbErrorCargo
            // 
            this.lbErrorCargo.AutoSize = true;
            this.lbErrorCargo.Font = new System.Drawing.Font("Microsoft Yi Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErrorCargo.ForeColor = System.Drawing.Color.Red;
            this.lbErrorCargo.Location = new System.Drawing.Point(183, 469);
            this.lbErrorCargo.Name = "lbErrorCargo";
            this.lbErrorCargo.Size = new System.Drawing.Size(76, 15);
            this.lbErrorCargo.TabIndex = 21;
            this.lbErrorCargo.Text = "Ingresar dato";
            // 
            // lbErrorContraseña
            // 
            this.lbErrorContraseña.AutoSize = true;
            this.lbErrorContraseña.Font = new System.Drawing.Font("Microsoft Yi Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErrorContraseña.ForeColor = System.Drawing.Color.Red;
            this.lbErrorContraseña.Location = new System.Drawing.Point(194, 426);
            this.lbErrorContraseña.Name = "lbErrorContraseña";
            this.lbErrorContraseña.Size = new System.Drawing.Size(76, 15);
            this.lbErrorContraseña.TabIndex = 20;
            this.lbErrorContraseña.Text = "Ingresar dato";
            // 
            // lbErrorUsuario
            // 
            this.lbErrorUsuario.AutoSize = true;
            this.lbErrorUsuario.Font = new System.Drawing.Font("Microsoft Yi Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErrorUsuario.ForeColor = System.Drawing.Color.Red;
            this.lbErrorUsuario.Location = new System.Drawing.Point(194, 380);
            this.lbErrorUsuario.Name = "lbErrorUsuario";
            this.lbErrorUsuario.Size = new System.Drawing.Size(76, 15);
            this.lbErrorUsuario.TabIndex = 19;
            this.lbErrorUsuario.Text = "Ingresar dato";
            // 
            // FormRegistrar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 605);
            this.Controls.Add(this.PanelEscritorio2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormRegistrar";
            this.Text = "FormRegistrar";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panelButons.ResumeLayout(false);
            this.panelButons.PerformLayout();
            this.PanelEscritorio2.ResumeLayout(false);
            this.PanelEscritorio2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDNI;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCodigoT;
        private System.Windows.Forms.TextBox txtContraseña;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnRegistrarse;
        private System.Windows.Forms.RadioButton rbtnJefe;
        private System.Windows.Forms.RadioButton rbtnTrabajador;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbRegresar;
        private System.Windows.Forms.Panel panelButons;
        private System.Windows.Forms.Panel PanelEscritorio2;
        private System.Windows.Forms.Label lbErrorNombre;
        private System.Windows.Forms.Label lbErrorDNI;
        private System.Windows.Forms.Label lbErroCorreo;
        private System.Windows.Forms.Label lbErrorDireccion;
        private System.Windows.Forms.Label lbErrorTelefono;
        private System.Windows.Forms.Label lbErrorContraseña;
        private System.Windows.Forms.Label lbErrorUsuario;
        private System.Windows.Forms.Label lbErrorCargo;
    }
}