﻿namespace Proyect_HardStore
{
    partial class Form_Compra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbErrorDNI = new System.Windows.Forms.Label();
            this.lbErrorTelefono = new System.Windows.Forms.Label();
            this.lbErrorNombre = new System.Windows.Forms.Label();
            this.lbTicket = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDNI = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombresApellidos = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.lbErrorEntrega = new System.Windows.Forms.Label();
            this.lbErrorMetodo = new System.Windows.Forms.Label();
            this.lbErrorCantidad = new System.Windows.Forms.Label();
            this.lbErrorCodigo = new System.Windows.Forms.Label();
            this.lbErrorProducto = new System.Windows.Forms.Label();
            this.cbMetodoPago = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.rbtnDomicilio = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.rbtnTienda = new System.Windows.Forms.RadioButton();
            this.lbPrecioTotal = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbPrecioUnitario = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtProducto = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.GbxDatosEnvio = new System.Windows.Forms.GroupBox();
            this.lbErrorDistrito = new System.Windows.Forms.Label();
            this.lbErrorReferencia = new System.Windows.Forms.Label();
            this.lbErrorDireccion = new System.Windows.Forms.Label();
            this.lbPrecioEnvio = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtReferencia = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtDistrito = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtDirreccion = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnBoleta = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dtgvPedidos = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.GbxDatosEnvio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPedidos)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbErrorDNI);
            this.groupBox1.Controls.Add(this.lbErrorTelefono);
            this.groupBox1.Controls.Add(this.lbErrorNombre);
            this.groupBox1.Controls.Add(this.lbTicket);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtDNI);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtTelefono);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtNombresApellidos);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(32, 100);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(247, 206);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos del cliente";
            // 
            // lbErrorDNI
            // 
            this.lbErrorDNI.AutoSize = true;
            this.lbErrorDNI.ForeColor = System.Drawing.Color.Red;
            this.lbErrorDNI.Location = new System.Drawing.Point(92, 145);
            this.lbErrorDNI.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorDNI.Name = "lbErrorDNI";
            this.lbErrorDNI.Size = new System.Drawing.Size(69, 13);
            this.lbErrorDNI.TabIndex = 11;
            this.lbErrorDNI.Text = "Ingresar dato";
            // 
            // lbErrorTelefono
            // 
            this.lbErrorTelefono.AutoSize = true;
            this.lbErrorTelefono.ForeColor = System.Drawing.Color.Red;
            this.lbErrorTelefono.Location = new System.Drawing.Point(92, 103);
            this.lbErrorTelefono.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorTelefono.Name = "lbErrorTelefono";
            this.lbErrorTelefono.Size = new System.Drawing.Size(69, 13);
            this.lbErrorTelefono.TabIndex = 10;
            this.lbErrorTelefono.Text = "Ingresar dato";
            // 
            // lbErrorNombre
            // 
            this.lbErrorNombre.AutoSize = true;
            this.lbErrorNombre.ForeColor = System.Drawing.Color.Red;
            this.lbErrorNombre.Location = new System.Drawing.Point(147, 65);
            this.lbErrorNombre.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorNombre.Name = "lbErrorNombre";
            this.lbErrorNombre.Size = new System.Drawing.Size(69, 13);
            this.lbErrorNombre.TabIndex = 9;
            this.lbErrorNombre.Text = "Ingresar dato";
            // 
            // lbTicket
            // 
            this.lbTicket.AutoSize = true;
            this.lbTicket.Location = new System.Drawing.Point(64, 162);
            this.lbTicket.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbTicket.Name = "lbTicket";
            this.lbTicket.Size = new System.Drawing.Size(58, 13);
            this.lbTicket.TabIndex = 8;
            this.lbTicket.Text = "-----------------";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 162);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Ticket:";
            // 
            // txtDNI
            // 
            this.txtDNI.Location = new System.Drawing.Point(67, 124);
            this.txtDNI.Margin = new System.Windows.Forms.Padding(2);
            this.txtDNI.Name = "txtDNI";
            this.txtDNI.Size = new System.Drawing.Size(90, 20);
            this.txtDNI.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 127);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "DNI :";
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(67, 85);
            this.txtTelefono.Margin = new System.Windows.Forms.Padding(2);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(90, 20);
            this.txtTelefono.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 88);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Telefono:";
            // 
            // txtNombresApellidos
            // 
            this.txtNombresApellidos.Location = new System.Drawing.Point(14, 45);
            this.txtNombresApellidos.Margin = new System.Windows.Forms.Padding(2);
            this.txtNombresApellidos.Name = "txtNombresApellidos";
            this.txtNombresApellidos.Size = new System.Drawing.Size(198, 20);
            this.txtNombresApellidos.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nombres y apellidos :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnAgregar);
            this.groupBox2.Controls.Add(this.lbErrorEntrega);
            this.groupBox2.Controls.Add(this.lbErrorMetodo);
            this.groupBox2.Controls.Add(this.lbErrorCantidad);
            this.groupBox2.Controls.Add(this.lbErrorCodigo);
            this.groupBox2.Controls.Add(this.lbErrorProducto);
            this.groupBox2.Controls.Add(this.cbMetodoPago);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.rbtnDomicilio);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.rbtnTienda);
            this.groupBox2.Controls.Add(this.lbPrecioTotal);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.lbPrecioUnitario);
            this.groupBox2.Controls.Add(this.txtCodigo);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtProducto);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtCantidad);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(302, 100);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(432, 206);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Datos del pedido";
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btnAgregar.FlatAppearance.BorderSize = 0;
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAgregar.Location = new System.Drawing.Point(223, 172);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(2);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(110, 25);
            this.btnAgregar.TabIndex = 28;
            this.btnAgregar.Text = "Agregar producto";
            this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // lbErrorEntrega
            // 
            this.lbErrorEntrega.AutoSize = true;
            this.lbErrorEntrega.ForeColor = System.Drawing.Color.Red;
            this.lbErrorEntrega.Location = new System.Drawing.Point(314, 81);
            this.lbErrorEntrega.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorEntrega.Name = "lbErrorEntrega";
            this.lbErrorEntrega.Size = new System.Drawing.Size(69, 13);
            this.lbErrorEntrega.TabIndex = 27;
            this.lbErrorEntrega.Text = "Ingresar dato";
            // 
            // lbErrorMetodo
            // 
            this.lbErrorMetodo.AutoSize = true;
            this.lbErrorMetodo.ForeColor = System.Drawing.Color.Red;
            this.lbErrorMetodo.Location = new System.Drawing.Point(334, 49);
            this.lbErrorMetodo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorMetodo.Name = "lbErrorMetodo";
            this.lbErrorMetodo.Size = new System.Drawing.Size(69, 13);
            this.lbErrorMetodo.TabIndex = 26;
            this.lbErrorMetodo.Text = "Ingresar dato";
            // 
            // lbErrorCantidad
            // 
            this.lbErrorCantidad.AutoSize = true;
            this.lbErrorCantidad.ForeColor = System.Drawing.Color.Red;
            this.lbErrorCantidad.Location = new System.Drawing.Point(110, 81);
            this.lbErrorCantidad.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorCantidad.Name = "lbErrorCantidad";
            this.lbErrorCantidad.Size = new System.Drawing.Size(69, 13);
            this.lbErrorCantidad.TabIndex = 25;
            this.lbErrorCantidad.Text = "Ingresar dato";
            // 
            // lbErrorCodigo
            // 
            this.lbErrorCodigo.AutoSize = true;
            this.lbErrorCodigo.ForeColor = System.Drawing.Color.Red;
            this.lbErrorCodigo.Location = new System.Drawing.Point(110, 43);
            this.lbErrorCodigo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorCodigo.Name = "lbErrorCodigo";
            this.lbErrorCodigo.Size = new System.Drawing.Size(69, 13);
            this.lbErrorCodigo.TabIndex = 24;
            this.lbErrorCodigo.Text = "Ingresar dato";
            // 
            // lbErrorProducto
            // 
            this.lbErrorProducto.AutoSize = true;
            this.lbErrorProducto.ForeColor = System.Drawing.Color.Red;
            this.lbErrorProducto.Location = new System.Drawing.Point(110, 121);
            this.lbErrorProducto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorProducto.Name = "lbErrorProducto";
            this.lbErrorProducto.Size = new System.Drawing.Size(69, 13);
            this.lbErrorProducto.TabIndex = 23;
            this.lbErrorProducto.Text = "Ingresar dato";
            // 
            // cbMetodoPago
            // 
            this.cbMetodoPago.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMetodoPago.FormattingEnabled = true;
            this.cbMetodoPago.Items.AddRange(new object[] {
            "Efectivo",
            "Tarjeta",
            "Trasferencia",
            "Pago con entrega"});
            this.cbMetodoPago.Location = new System.Drawing.Point(308, 27);
            this.cbMetodoPago.Margin = new System.Windows.Forms.Padding(2);
            this.cbMetodoPago.Name = "cbMetodoPago";
            this.cbMetodoPago.Size = new System.Drawing.Size(92, 21);
            this.cbMetodoPago.TabIndex = 22;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(224, 81);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 13);
            this.label15.TabIndex = 14;
            this.label15.Text = "Tipo de entrega:";
            // 
            // rbtnDomicilio
            // 
            this.rbtnDomicilio.AutoSize = true;
            this.rbtnDomicilio.Location = new System.Drawing.Point(262, 136);
            this.rbtnDomicilio.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnDomicilio.Name = "rbtnDomicilio";
            this.rbtnDomicilio.Size = new System.Drawing.Size(104, 17);
            this.rbtnDomicilio.TabIndex = 3;
            this.rbtnDomicilio.TabStop = true;
            this.rbtnDomicilio.Text = "Envio a domicilio";
            this.rbtnDomicilio.UseVisualStyleBackColor = true;
            this.rbtnDomicilio.CheckedChanged += new System.EventHandler(this.rbtnDomicilio_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(220, 27);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(88, 13);
            this.label16.TabIndex = 21;
            this.label16.Text = "Metodo de pago:";
            // 
            // rbtnTienda
            // 
            this.rbtnTienda.AutoSize = true;
            this.rbtnTienda.Location = new System.Drawing.Point(262, 106);
            this.rbtnTienda.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnTienda.Name = "rbtnTienda";
            this.rbtnTienda.Size = new System.Drawing.Size(100, 17);
            this.rbtnTienda.TabIndex = 2;
            this.rbtnTienda.TabStop = true;
            this.rbtnTienda.Text = "Retiro en tienda";
            this.rbtnTienda.UseVisualStyleBackColor = true;
            this.rbtnTienda.CheckedChanged += new System.EventHandler(this.rbtnTienda_CheckedChanged);
            // 
            // lbPrecioTotal
            // 
            this.lbPrecioTotal.AutoSize = true;
            this.lbPrecioTotal.Location = new System.Drawing.Point(98, 178);
            this.lbPrecioTotal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbPrecioTotal.Name = "lbPrecioTotal";
            this.lbPrecioTotal.Size = new System.Drawing.Size(61, 13);
            this.lbPrecioTotal.TabIndex = 18;
            this.lbPrecioTotal.Text = "------------------";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(22, 178);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 17;
            this.label12.Text = "Precio total:";
            // 
            // lbPrecioUnitario
            // 
            this.lbPrecioUnitario.AutoSize = true;
            this.lbPrecioUnitario.Location = new System.Drawing.Point(98, 150);
            this.lbPrecioUnitario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbPrecioUnitario.Name = "lbPrecioUnitario";
            this.lbPrecioUnitario.Size = new System.Drawing.Size(61, 13);
            this.lbPrecioUnitario.TabIndex = 16;
            this.lbPrecioUnitario.Text = "------------------";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(86, 24);
            this.txtCodigo.Margin = new System.Windows.Forms.Padding(2);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(90, 20);
            this.txtCodigo.TabIndex = 14;
            this.txtCodigo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCodigo_KeyDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(26, 24);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Código:";
            // 
            // txtProducto
            // 
            this.txtProducto.Location = new System.Drawing.Point(86, 103);
            this.txtProducto.Margin = new System.Windows.Forms.Padding(2);
            this.txtProducto.Name = "txtProducto";
            this.txtProducto.Size = new System.Drawing.Size(90, 20);
            this.txtProducto.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 106);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Producto:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 150);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Precio unitario:";
            // 
            // txtCantidad
            // 
            this.txtCantidad.Location = new System.Drawing.Point(86, 61);
            this.txtCantidad.Margin = new System.Windows.Forms.Padding(2);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(90, 20);
            this.txtCantidad.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 61);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Cantidad:";
            // 
            // GbxDatosEnvio
            // 
            this.GbxDatosEnvio.Controls.Add(this.lbErrorDistrito);
            this.GbxDatosEnvio.Controls.Add(this.lbErrorReferencia);
            this.GbxDatosEnvio.Controls.Add(this.lbErrorDireccion);
            this.GbxDatosEnvio.Controls.Add(this.lbPrecioEnvio);
            this.GbxDatosEnvio.Controls.Add(this.label20);
            this.GbxDatosEnvio.Controls.Add(this.txtReferencia);
            this.GbxDatosEnvio.Controls.Add(this.label19);
            this.GbxDatosEnvio.Controls.Add(this.txtDistrito);
            this.GbxDatosEnvio.Controls.Add(this.label18);
            this.GbxDatosEnvio.Controls.Add(this.txtDirreccion);
            this.GbxDatosEnvio.Controls.Add(this.label17);
            this.GbxDatosEnvio.Location = new System.Drawing.Point(9, 339);
            this.GbxDatosEnvio.Margin = new System.Windows.Forms.Padding(2);
            this.GbxDatosEnvio.Name = "GbxDatosEnvio";
            this.GbxDatosEnvio.Padding = new System.Windows.Forms.Padding(2);
            this.GbxDatosEnvio.Size = new System.Drawing.Size(309, 171);
            this.GbxDatosEnvio.TabIndex = 15;
            this.GbxDatosEnvio.TabStop = false;
            this.GbxDatosEnvio.Text = "Datos de envio";
            // 
            // lbErrorDistrito
            // 
            this.lbErrorDistrito.AutoSize = true;
            this.lbErrorDistrito.ForeColor = System.Drawing.Color.Red;
            this.lbErrorDistrito.Location = new System.Drawing.Point(123, 113);
            this.lbErrorDistrito.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorDistrito.Name = "lbErrorDistrito";
            this.lbErrorDistrito.Size = new System.Drawing.Size(69, 13);
            this.lbErrorDistrito.TabIndex = 20;
            this.lbErrorDistrito.Text = "Ingresar dato";
            // 
            // lbErrorReferencia
            // 
            this.lbErrorReferencia.AutoSize = true;
            this.lbErrorReferencia.ForeColor = System.Drawing.Color.Red;
            this.lbErrorReferencia.Location = new System.Drawing.Point(224, 82);
            this.lbErrorReferencia.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorReferencia.Name = "lbErrorReferencia";
            this.lbErrorReferencia.Size = new System.Drawing.Size(69, 13);
            this.lbErrorReferencia.TabIndex = 19;
            this.lbErrorReferencia.Text = "Ingresar dato";
            // 
            // lbErrorDireccion
            // 
            this.lbErrorDireccion.AutoSize = true;
            this.lbErrorDireccion.ForeColor = System.Drawing.Color.Red;
            this.lbErrorDireccion.Location = new System.Drawing.Point(224, 40);
            this.lbErrorDireccion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbErrorDireccion.Name = "lbErrorDireccion";
            this.lbErrorDireccion.Size = new System.Drawing.Size(69, 13);
            this.lbErrorDireccion.TabIndex = 18;
            this.lbErrorDireccion.Text = "Ingresar dato";
            // 
            // lbPrecioEnvio
            // 
            this.lbPrecioEnvio.AutoSize = true;
            this.lbPrecioEnvio.Location = new System.Drawing.Point(106, 142);
            this.lbPrecioEnvio.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbPrecioEnvio.Name = "lbPrecioEnvio";
            this.lbPrecioEnvio.Size = new System.Drawing.Size(25, 13);
            this.lbPrecioEnvio.TabIndex = 17;
            this.lbPrecioEnvio.Text = "$----";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(14, 142);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 13);
            this.label20.TabIndex = 16;
            this.label20.Text = "Precio de envio:";
            // 
            // txtReferencia
            // 
            this.txtReferencia.Location = new System.Drawing.Point(74, 62);
            this.txtReferencia.Margin = new System.Windows.Forms.Padding(2);
            this.txtReferencia.Name = "txtReferencia";
            this.txtReferencia.Size = new System.Drawing.Size(218, 20);
            this.txtReferencia.TabIndex = 14;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(15, 64);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(62, 13);
            this.label19.TabIndex = 15;
            this.label19.Text = "Referencia:";
            // 
            // txtDistrito
            // 
            this.txtDistrito.Location = new System.Drawing.Point(74, 93);
            this.txtDistrito.Margin = new System.Windows.Forms.Padding(2);
            this.txtDistrito.Name = "txtDistrito";
            this.txtDistrito.Size = new System.Drawing.Size(114, 20);
            this.txtDistrito.TabIndex = 12;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(15, 95);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(42, 13);
            this.label18.TabIndex = 13;
            this.label18.Text = "Distrito:";
            // 
            // txtDirreccion
            // 
            this.txtDirreccion.Location = new System.Drawing.Point(74, 20);
            this.txtDirreccion.Margin = new System.Windows.Forms.Padding(2);
            this.txtDirreccion.Name = "txtDirreccion";
            this.txtDirreccion.Size = new System.Drawing.Size(218, 20);
            this.txtDirreccion.TabIndex = 10;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 22);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 13);
            this.label17.TabIndex = 11;
            this.label17.Text = "Dirección:";
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCancelar.Location = new System.Drawing.Point(170, 11);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(108, 24);
            this.btnCancelar.TabIndex = 18;
            this.btnCancelar.Text = "Cancelar pedido ";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnBoleta
            // 
            this.btnBoleta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btnBoleta.FlatAppearance.BorderSize = 0;
            this.btnBoleta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBoleta.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBoleta.Location = new System.Drawing.Point(302, 10);
            this.btnBoleta.Margin = new System.Windows.Forms.Padding(2);
            this.btnBoleta.Name = "btnBoleta";
            this.btnBoleta.Size = new System.Drawing.Size(98, 24);
            this.btnBoleta.TabIndex = 19;
            this.btnBoleta.Text = "Imprimir boleta";
            this.btnBoleta.UseVisualStyleBackColor = false;
            this.btnBoleta.Click += new System.EventHandler(this.btnBoleta_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Proyect_HardStore.Properties.Resources.images_Photoroom;
            this.pictureBox5.Location = new System.Drawing.Point(190, 40);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(53, 43);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 24;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Proyect_HardStore.Properties.Resources.unnamed_removebg_preview;
            this.pictureBox4.Location = new System.Drawing.Point(316, 25);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(67, 70);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 23;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Proyect_HardStore.Properties.Resources.images_removebg_preview__3_;
            this.pictureBox3.Location = new System.Drawing.Point(49, 40);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(40, 43);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 22;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Proyect_HardStore.Properties.Resources.iconos_05_removebg_preview;
            this.pictureBox2.Location = new System.Drawing.Point(625, 10);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(109, 94);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 21;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyect_HardStore.Properties.Resources.concepto_entrega_diseno_plano_23_2149146359_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(9, 516);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(309, 153);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // dtgvPedidos
            // 
            this.dtgvPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvPedidos.Location = new System.Drawing.Point(342, 339);
            this.dtgvPedidos.Margin = new System.Windows.Forms.Padding(2);
            this.dtgvPedidos.Name = "dtgvPedidos";
            this.dtgvPedidos.ReadOnly = true;
            this.dtgvPedidos.RowHeadersWidth = 51;
            this.dtgvPedidos.RowTemplate.Height = 24;
            this.dtgvPedidos.Size = new System.Drawing.Size(380, 294);
            this.dtgvPedidos.TabIndex = 25;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(26, 10);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 25);
            this.button1.TabIndex = 17;
            this.button1.Text = "Finaizar pedido";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnFinalizar_Click);
            // 
            // Form_Compra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 656);
            this.Controls.Add(this.dtgvPedidos);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnBoleta);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.GbxDatosEnvio);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox4);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form_Compra";
            this.Text = "atencion_cliente";
            this.Load += new System.EventHandler(this.Form_Compra_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.GbxDatosEnvio.ResumeLayout(false);
            this.GbxDatosEnvio.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPedidos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbTicket;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDNI;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombresApellidos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtProducto;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCantidad;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbMetodoPago;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbPrecioTotal;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbPrecioUnitario;
        private System.Windows.Forms.RadioButton rbtnDomicilio;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton rbtnTienda;
        private System.Windows.Forms.GroupBox GbxDatosEnvio;
        private System.Windows.Forms.Label lbPrecioEnvio;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtReferencia;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtDistrito;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtDirreccion;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnBoleta;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lbErrorDNI;
        private System.Windows.Forms.Label lbErrorTelefono;
        private System.Windows.Forms.Label lbErrorNombre;
        private System.Windows.Forms.Label lbErrorEntrega;
        private System.Windows.Forms.Label lbErrorMetodo;
        private System.Windows.Forms.Label lbErrorCantidad;
        private System.Windows.Forms.Label lbErrorCodigo;
        private System.Windows.Forms.Label lbErrorProducto;
        private System.Windows.Forms.Label lbErrorDistrito;
        private System.Windows.Forms.Label lbErrorReferencia;
        private System.Windows.Forms.Label lbErrorDireccion;
        private System.Windows.Forms.DataGridView dtgvPedidos;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button button1;
    }
}