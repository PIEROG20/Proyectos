﻿namespace Proyect_HardStore
{
    partial class atencion_cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose();
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atencion_cliente));
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCliente = new System.Windows.Forms.TextBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnatenderpedido = new System.Windows.Forms.Button();
            this.btncancelarpedido = new System.Windows.Forms.Button();
            this.dgvAtendidos = new System.Windows.Forms.DataGridView();
            this.dgvEspera = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbErrorCliente = new System.Windows.Forms.Label();
            this.btnimprimir = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAtendidos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEspera)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cliente:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tipo de atencion";
            // 
            // txtCliente
            // 
            this.txtCliente.Location = new System.Drawing.Point(17, 37);
            this.txtCliente.Name = "txtCliente";
            this.txtCliente.Size = new System.Drawing.Size(99, 20);
            this.txtCliente.TabIndex = 4;
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btnAgregar.FlatAppearance.BorderSize = 0;
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.ForeColor = System.Drawing.Color.White;
            this.btnAgregar.Location = new System.Drawing.Point(368, 19);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(115, 24);
            this.btnAgregar.TabIndex = 11;
            this.btnAgregar.Text = "Nuevo Pedido";
            this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btnatenderpedido
            // 
            this.btnatenderpedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btnatenderpedido.FlatAppearance.BorderSize = 0;
            this.btnatenderpedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnatenderpedido.ForeColor = System.Drawing.Color.White;
            this.btnatenderpedido.Location = new System.Drawing.Point(368, 96);
            this.btnatenderpedido.Name = "btnatenderpedido";
            this.btnatenderpedido.Size = new System.Drawing.Size(115, 30);
            this.btnatenderpedido.TabIndex = 12;
            this.btnatenderpedido.Text = "Atender Pedido";
            this.btnatenderpedido.UseVisualStyleBackColor = false;
            this.btnatenderpedido.Click += new System.EventHandler(this.btnatenderpedido_Click);
            // 
            // btncancelarpedido
            // 
            this.btncancelarpedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btncancelarpedido.FlatAppearance.BorderSize = 0;
            this.btncancelarpedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncancelarpedido.ForeColor = System.Drawing.Color.White;
            this.btncancelarpedido.Location = new System.Drawing.Point(368, 56);
            this.btncancelarpedido.Name = "btncancelarpedido";
            this.btncancelarpedido.Size = new System.Drawing.Size(115, 27);
            this.btncancelarpedido.TabIndex = 13;
            this.btncancelarpedido.Text = "Cancelar Pedido";
            this.btncancelarpedido.UseVisualStyleBackColor = false;
            this.btncancelarpedido.Click += new System.EventHandler(this.btncancelarpedido_Click);
            // 
            // dgvAtendidos
            // 
            this.dgvAtendidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAtendidos.Location = new System.Drawing.Point(14, 29);
            this.dgvAtendidos.Margin = new System.Windows.Forms.Padding(2);
            this.dgvAtendidos.Name = "dgvAtendidos";
            this.dgvAtendidos.ReadOnly = true;
            this.dgvAtendidos.RowHeadersWidth = 51;
            this.dgvAtendidos.RowTemplate.Height = 24;
            this.dgvAtendidos.Size = new System.Drawing.Size(309, 202);
            this.dgvAtendidos.TabIndex = 15;
            // 
            // dgvEspera
            // 
            this.dgvEspera.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEspera.Location = new System.Drawing.Point(19, 29);
            this.dgvEspera.Margin = new System.Windows.Forms.Padding(2);
            this.dgvEspera.Name = "dgvEspera";
            this.dgvEspera.ReadOnly = true;
            this.dgvEspera.RowHeadersWidth = 51;
            this.dgvEspera.RowTemplate.Height = 24;
            this.dgvEspera.Size = new System.Drawing.Size(271, 202);
            this.dgvEspera.TabIndex = 17;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lbErrorCliente);
            this.groupBox1.Controls.Add(this.btnimprimir);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtCliente);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Location = new System.Drawing.Point(19, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(344, 154);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos ";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Compra";
            // 
            // lbErrorCliente
            // 
            this.lbErrorCliente.AutoSize = true;
            this.lbErrorCliente.ForeColor = System.Drawing.Color.Red;
            this.lbErrorCliente.Location = new System.Drawing.Point(51, 55);
            this.lbErrorCliente.Name = "lbErrorCliente";
            this.lbErrorCliente.Size = new System.Drawing.Size(69, 13);
            this.lbErrorCliente.TabIndex = 14;
            this.lbErrorCliente.Text = "Ingresar dato";
            // 
            // btnimprimir
            // 
            this.btnimprimir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btnimprimir.FlatAppearance.BorderSize = 0;
            this.btnimprimir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnimprimir.ForeColor = System.Drawing.Color.White;
            this.btnimprimir.Location = new System.Drawing.Point(161, 46);
            this.btnimprimir.Name = "btnimprimir";
            this.btnimprimir.Size = new System.Drawing.Size(81, 23);
            this.btnimprimir.TabIndex = 12;
            this.btnimprimir.Text = "Imprimir";
            this.btnimprimir.UseVisualStyleBackColor = false;
            this.btnimprimir.Click += new System.EventHandler(this.btnimprimir_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(197, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(159, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Número de ticket:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Proyect_HardStore.Properties.Resources.unnamed_removebg_preview;
            this.pictureBox2.Location = new System.Drawing.Point(218, 41);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 86);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvEspera);
            this.groupBox2.Location = new System.Drawing.Point(9, 187);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(306, 255);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "En espera";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvAtendidos);
            this.groupBox3.Location = new System.Drawing.Point(326, 187);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(346, 255);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Atendidos";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(506, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(154, 142);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // atencion_cliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 451);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btncancelarpedido);
            this.Controls.Add(this.btnatenderpedido);
            this.Controls.Add(this.btnAgregar);
            this.Name = "atencion_cliente";
            this.Text = "atencion_cliente";
            this.Load += new System.EventHandler(this.atencion_cliente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAtendidos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEspera)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCliente;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnatenderpedido;
        private System.Windows.Forms.Button btncancelarpedido;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dgvAtendidos;
        private System.Windows.Forms.DataGridView dgvEspera;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnimprimir;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbErrorCliente;
        private System.Windows.Forms.Label label3;
    }
}
