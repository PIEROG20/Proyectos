﻿namespace Proyect_HardStore
{
    partial class Almacen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxcontrolygestiondesecciones = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAgregaraList = new System.Windows.Forms.Button();
            this.listBoxRuta = new System.Windows.Forms.ListBox();
            this.buttonRecorridomulti = new System.Windows.Forms.Button();
            this.comboBoxRutaAlista = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBoxCalcularrutaderecoleccion = new System.Windows.Forms.GroupBox();
            this.textBoxInicio = new System.Windows.Forms.TextBox();
            this.btncalcularrutaoptima = new System.Windows.Forms.Button();
            this.comboBoxfinRutasimple = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBoxNuevaSeccion = new System.Windows.Forms.GroupBox();
            this.textBoxCategoriaNombre = new System.Windows.Forms.TextBox();
            this.numericUpDownPeso = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.btnagregarseccion = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxVisualizaciondelmapa = new System.Windows.Forms.GroupBox();
            this.pictureBoxvisualizaciondelmapa = new System.Windows.Forms.PictureBox();
            this.groupBoxcontrolygestiondesecciones.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBoxCalcularrutaderecoleccion.SuspendLayout();
            this.groupBoxNuevaSeccion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPeso)).BeginInit();
            this.groupBoxVisualizaciondelmapa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxvisualizaciondelmapa)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxcontrolygestiondesecciones
            // 
            this.groupBoxcontrolygestiondesecciones.BackColor = System.Drawing.Color.LightSeaGreen;
            this.groupBoxcontrolygestiondesecciones.Controls.Add(this.groupBox1);
            this.groupBoxcontrolygestiondesecciones.Controls.Add(this.groupBoxCalcularrutaderecoleccion);
            this.groupBoxcontrolygestiondesecciones.Controls.Add(this.groupBoxNuevaSeccion);
            this.groupBoxcontrolygestiondesecciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxcontrolygestiondesecciones.Location = new System.Drawing.Point(6, 4);
            this.groupBoxcontrolygestiondesecciones.Name = "groupBoxcontrolygestiondesecciones";
            this.groupBoxcontrolygestiondesecciones.Size = new System.Drawing.Size(363, 583);
            this.groupBoxcontrolygestiondesecciones.TabIndex = 0;
            this.groupBoxcontrolygestiondesecciones.TabStop = false;
            this.groupBoxcontrolygestiondesecciones.Text = "CONTROL Y GESTION DE SECCIONES";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnAgregaraList);
            this.groupBox1.Controls.Add(this.listBoxRuta);
            this.groupBox1.Controls.Add(this.buttonRecorridomulti);
            this.groupBox1.Controls.Add(this.comboBoxRutaAlista);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(15, 326);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(330, 239);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "CALCULAR RUTA DE RECOLECCION";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Ruta:";
            // 
            // btnAgregaraList
            // 
            this.btnAgregaraList.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnAgregaraList.Location = new System.Drawing.Point(123, 46);
            this.btnAgregaraList.Name = "btnAgregaraList";
            this.btnAgregaraList.Size = new System.Drawing.Size(172, 23);
            this.btnAgregaraList.TabIndex = 11;
            this.btnAgregaraList.Text = "AGREGAR A RUTA";
            this.btnAgregaraList.UseVisualStyleBackColor = false;
            this.btnAgregaraList.Click += new System.EventHandler(this.btnAgregaraList_Click);
            // 
            // listBoxRuta
            // 
            this.listBoxRuta.FormattingEnabled = true;
            this.listBoxRuta.Location = new System.Drawing.Point(6, 109);
            this.listBoxRuta.Name = "listBoxRuta";
            this.listBoxRuta.Size = new System.Drawing.Size(301, 95);
            this.listBoxRuta.TabIndex = 10;
            // 
            // buttonRecorridomulti
            // 
            this.buttonRecorridomulti.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonRecorridomulti.Location = new System.Drawing.Point(86, 210);
            this.buttonRecorridomulti.Name = "buttonRecorridomulti";
            this.buttonRecorridomulti.Size = new System.Drawing.Size(172, 23);
            this.buttonRecorridomulti.TabIndex = 6;
            this.buttonRecorridomulti.Text = "CALCULAR RUTA OPTIMA";
            this.buttonRecorridomulti.UseVisualStyleBackColor = false;
            this.buttonRecorridomulti.Click += new System.EventHandler(this.buttonRecorridomulti_Click);
            // 
            // comboBoxRutaAlista
            // 
            this.comboBoxRutaAlista.FormattingEnabled = true;
            this.comboBoxRutaAlista.Items.AddRange(new object[] {
            "Manuales",
            "Electricas",
            "Medición ",
            "Neumatícas",
            "Industrial",
            "Soldadura",
            "Construcción"});
            this.comboBoxRutaAlista.Location = new System.Drawing.Point(99, 19);
            this.comboBoxRutaAlista.Name = "comboBoxRutaAlista";
            this.comboBoxRutaAlista.Size = new System.Drawing.Size(196, 21);
            this.comboBoxRutaAlista.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Fin";
            // 
            // groupBoxCalcularrutaderecoleccion
            // 
            this.groupBoxCalcularrutaderecoleccion.BackColor = System.Drawing.Color.White;
            this.groupBoxCalcularrutaderecoleccion.Controls.Add(this.textBoxInicio);
            this.groupBoxCalcularrutaderecoleccion.Controls.Add(this.btncalcularrutaoptima);
            this.groupBoxCalcularrutaderecoleccion.Controls.Add(this.comboBoxfinRutasimple);
            this.groupBoxCalcularrutaderecoleccion.Controls.Add(this.label7);
            this.groupBoxCalcularrutaderecoleccion.Controls.Add(this.label6);
            this.groupBoxCalcularrutaderecoleccion.Location = new System.Drawing.Point(15, 175);
            this.groupBoxCalcularrutaderecoleccion.Name = "groupBoxCalcularrutaderecoleccion";
            this.groupBoxCalcularrutaderecoleccion.Size = new System.Drawing.Size(330, 145);
            this.groupBoxCalcularrutaderecoleccion.TabIndex = 2;
            this.groupBoxCalcularrutaderecoleccion.TabStop = false;
            this.groupBoxCalcularrutaderecoleccion.Text = "CALCULAR RUTA DE RECOLECCION";
            // 
            // textBoxInicio
            // 
            this.textBoxInicio.Enabled = false;
            this.textBoxInicio.Location = new System.Drawing.Point(99, 35);
            this.textBoxInicio.Name = "textBoxInicio";
            this.textBoxInicio.Size = new System.Drawing.Size(196, 20);
            this.textBoxInicio.TabIndex = 7;
            this.textBoxInicio.Text = "Area de ventas";
            // 
            // btncalcularrutaoptima
            // 
            this.btncalcularrutaoptima.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btncalcularrutaoptima.Location = new System.Drawing.Point(108, 100);
            this.btncalcularrutaoptima.Name = "btncalcularrutaoptima";
            this.btncalcularrutaoptima.Size = new System.Drawing.Size(172, 23);
            this.btncalcularrutaoptima.TabIndex = 6;
            this.btncalcularrutaoptima.Text = "CALCULAR RUTA OPTIMA";
            this.btncalcularrutaoptima.UseVisualStyleBackColor = false;
            this.btncalcularrutaoptima.Click += new System.EventHandler(this.btncalcularrutaoptima_Click);
            // 
            // comboBoxfinRutasimple
            // 
            this.comboBoxfinRutasimple.FormattingEnabled = true;
            this.comboBoxfinRutasimple.Items.AddRange(new object[] {
            "Manuales",
            "Electricas",
            "Medición ",
            "Neumatícas",
            "Industrial",
            "Soldadura",
            "Construcción"});
            this.comboBoxfinRutasimple.Location = new System.Drawing.Point(99, 61);
            this.comboBoxfinRutasimple.Name = "comboBoxfinRutasimple";
            this.comboBoxfinRutasimple.Size = new System.Drawing.Size(196, 21);
            this.comboBoxfinRutasimple.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Fin";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Inicio";
            // 
            // groupBoxNuevaSeccion
            // 
            this.groupBoxNuevaSeccion.BackColor = System.Drawing.Color.White;
            this.groupBoxNuevaSeccion.Controls.Add(this.textBoxCategoriaNombre);
            this.groupBoxNuevaSeccion.Controls.Add(this.numericUpDownPeso);
            this.groupBoxNuevaSeccion.Controls.Add(this.label3);
            this.groupBoxNuevaSeccion.Controls.Add(this.btnagregarseccion);
            this.groupBoxNuevaSeccion.Controls.Add(this.label2);
            this.groupBoxNuevaSeccion.Location = new System.Drawing.Point(15, 24);
            this.groupBoxNuevaSeccion.Name = "groupBoxNuevaSeccion";
            this.groupBoxNuevaSeccion.Size = new System.Drawing.Size(330, 138);
            this.groupBoxNuevaSeccion.TabIndex = 0;
            this.groupBoxNuevaSeccion.TabStop = false;
            this.groupBoxNuevaSeccion.Text = "EDITAR SECCION";
            // 
            // textBoxCategoriaNombre
            // 
            this.textBoxCategoriaNombre.Enabled = false;
            this.textBoxCategoriaNombre.Location = new System.Drawing.Point(142, 16);
            this.textBoxCategoriaNombre.Name = "textBoxCategoriaNombre";
            this.textBoxCategoriaNombre.Size = new System.Drawing.Size(168, 20);
            this.textBoxCategoriaNombre.TabIndex = 9;
            // 
            // numericUpDownPeso
            // 
            this.numericUpDownPeso.Location = new System.Drawing.Point(162, 51);
            this.numericUpDownPeso.Name = "numericUpDownPeso";
            this.numericUpDownPeso.Size = new System.Drawing.Size(50, 20);
            this.numericUpDownPeso.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "PESO ESTIMADO";
            // 
            // btnagregarseccion
            // 
            this.btnagregarseccion.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnagregarseccion.Location = new System.Drawing.Point(86, 98);
            this.btnagregarseccion.Name = "btnagregarseccion";
            this.btnagregarseccion.Size = new System.Drawing.Size(136, 23);
            this.btnagregarseccion.TabIndex = 2;
            this.btnagregarseccion.Text = "GUARDAR CAMBIOS";
            this.btnagregarseccion.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "TIPO DE PRODUCTO";
            // 
            // groupBoxVisualizaciondelmapa
            // 
            this.groupBoxVisualizaciondelmapa.BackColor = System.Drawing.Color.LightSeaGreen;
            this.groupBoxVisualizaciondelmapa.Controls.Add(this.pictureBoxvisualizaciondelmapa);
            this.groupBoxVisualizaciondelmapa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxVisualizaciondelmapa.Location = new System.Drawing.Point(383, 7);
            this.groupBoxVisualizaciondelmapa.Name = "groupBoxVisualizaciondelmapa";
            this.groupBoxVisualizaciondelmapa.Size = new System.Drawing.Size(437, 580);
            this.groupBoxVisualizaciondelmapa.TabIndex = 1;
            this.groupBoxVisualizaciondelmapa.TabStop = false;
            this.groupBoxVisualizaciondelmapa.Text = "VISUALIZACION DEL MAPA";
            // 
            // pictureBoxvisualizaciondelmapa
            // 
            this.pictureBoxvisualizaciondelmapa.BackColor = System.Drawing.Color.White;
            this.pictureBoxvisualizaciondelmapa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxvisualizaciondelmapa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxvisualizaciondelmapa.Location = new System.Drawing.Point(17, 40);
            this.pictureBoxvisualizaciondelmapa.Name = "pictureBoxvisualizaciondelmapa";
            this.pictureBoxvisualizaciondelmapa.Size = new System.Drawing.Size(400, 500);
            this.pictureBoxvisualizaciondelmapa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxvisualizaciondelmapa.TabIndex = 0;
            this.pictureBoxvisualizaciondelmapa.TabStop = false;
            // 
            // Almacen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(837, 599);
            this.Controls.Add(this.groupBoxVisualizaciondelmapa);
            this.Controls.Add(this.groupBoxcontrolygestiondesecciones);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Almacen";
            this.Text = "Almacen";
            this.Load += new System.EventHandler(this.Almacen_Load);
            this.groupBoxcontrolygestiondesecciones.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxCalcularrutaderecoleccion.ResumeLayout(false);
            this.groupBoxCalcularrutaderecoleccion.PerformLayout();
            this.groupBoxNuevaSeccion.ResumeLayout(false);
            this.groupBoxNuevaSeccion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPeso)).EndInit();
            this.groupBoxVisualizaciondelmapa.ResumeLayout(false);
            this.groupBoxVisualizaciondelmapa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxvisualizaciondelmapa)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxcontrolygestiondesecciones;
        private System.Windows.Forms.GroupBox groupBoxCalcularrutaderecoleccion;
        private System.Windows.Forms.GroupBox groupBoxNuevaSeccion;
        private System.Windows.Forms.GroupBox groupBoxVisualizaciondelmapa;
        private System.Windows.Forms.PictureBox pictureBoxvisualizaciondelmapa;
        private System.Windows.Forms.Button btnagregarseccion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btncalcularrutaoptima;
        private System.Windows.Forms.ComboBox comboBoxfinRutasimple;
        private System.Windows.Forms.NumericUpDown numericUpDownPeso;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonRecorridomulti;
        private System.Windows.Forms.ComboBox comboBoxRutaAlista;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxInicio;
        private System.Windows.Forms.TextBox textBoxCategoriaNombre;
        private System.Windows.Forms.ListBox listBoxRuta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAgregaraList;
    }
}