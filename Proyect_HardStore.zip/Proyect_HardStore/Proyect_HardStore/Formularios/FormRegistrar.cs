﻿using Proyect_HardStore.Estructura_de_datos;
using Proyect_HardStore.Metodo_Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    public partial class FormRegistrar : Form
    {
        MetodoFormHijos Metodoform = new MetodoFormHijos();

        // flag para modo edición
        private bool isEdit = false;
        private Usuario editingUser = null;

        public FormRegistrar()
        {
            InitializeComponent();
            BaseDeDatosUsuarios.CargarDesdeCsv();
            lbErrorNombre.Visible = false;
            lbErrorTelefono.Visible = false;
            lbErrorDireccion.Visible = false;
            lbErrorDNI.Visible = false;
            lbErrorCargo.Visible = false;
            lbErroCorreo.Visible = false;
            lbErrorUsuario.Visible = false;
            lbErrorContraseña.Visible = false;

        }

        // Nuevo constructor para editar un usuario existente
        public FormRegistrar(Usuario usuario) : this()
        {
            if (usuario == null) return;
            isEdit = true;
            editingUser = usuario;

            // Rellenar controles con los datos del usuario
            txtNombre.Text = usuario.NombreApellido;
            txtTelefono.Text = usuario.Telefono.ToString();
            txtDireccion.Text = usuario.Direccion;
            txtCorreo.Text = usuario.Correo;
            txtDNI.Text = usuario.DNI.ToString();
            if (usuario.TipoUsuario == "Trabajador")
                rbtnTrabajador.Checked = true;
            else
                rbtnJefe.Checked = true;
            txtCodigoT.Text = usuario.IDtrabajador.ToString();
            txtCargo.Text = usuario.Cargo;
            txtUsuario.Text = usuario.usuario;
            txtContraseña.Text = usuario.Contraseña;

            // Cambiar texto del botón para indicar edición
            btnRegistrarse.Text = "Guardar cambios";
        }

        private void btnRegistrarse_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtTelefono.Text, out int telefono) || txtTelefono.Text.Length !=9)
                {
                    MessageBox.Show("Por favor ingrese un número valido de 9 digitos");
                    return;
                }
                if (!int.TryParse(txtDNI.Text, out int DNI) || txtDNI.Text.Length != 8)
                {
                    MessageBox.Show("Ingrese un DNI valido ");
                    return;
                }
                if (!int.TryParse(txtCodigoT.Text, out int IDusurio) || txtCodigoT.Text.Length != 8)
                {
                    MessageBox.Show("Ingrese su ID de usuario de 8 digitos");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtNombre.Text))
                {
                    lbErrorNombre.Visible = true;
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtTelefono.Text))
                {
                    lbErrorTelefono.Visible = true;
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtDireccion.Text))
                {
                    lbErrorDireccion.Visible = true;
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCorreo.Text))
                {
                    lbErroCorreo.Visible = true;
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtDNI.Text))
                {
                    lbErrorDNI.Visible = true;
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCargo.Text))
                {
                    lbErrorCargo.Visible = true;
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtUsuario.Text))
                {
                    lbErrorUsuario.Visible = true;
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtContraseña.Text))
                {
                    lbErrorContraseña.Visible = true;
                    return;
                }
                string tipoUsuario = rbtnTrabajador.Checked ? "Trabajador" : "Jefe";

                if (isEdit && editingUser != null)
                {
                    // Actualizar usuario existente
                    editingUser.NombreApellido = txtNombre.Text;
                    editingUser.Telefono = int.Parse(txtTelefono.Text);
                    editingUser.Direccion = txtDireccion.Text;
                    editingUser.Correo = txtCorreo.Text;
                    editingUser.DNI = int.Parse(txtDNI.Text);
                    editingUser.TipoUsuario = tipoUsuario;
                    editingUser.IDtrabajador = int.Parse(txtCodigoT.Text);
                    editingUser.Cargo = txtCargo.Text;
                    editingUser.usuario = txtUsuario.Text;
                    editingUser.Contraseña = txtContraseña.Text;

                    // Guardar cambios en CSV
                    BaseDeDatosUsuarios.GuardarEnCsv();

                    MessageBox.Show("Usuario actualizado correctamente.", "Éxito",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                    return;
                }

                Usuario nuevo = new Usuario(
                    txtNombre.Text,
                    int.Parse(txtTelefono.Text),
                    txtDireccion.Text,
                    txtCorreo.Text,
                    int.Parse(txtDNI.Text),
                    tipoUsuario,
                     int.Parse(txtCodigoT.Text),
                    txtCargo.Text,
                    txtUsuario.Text,
                    txtContraseña.Text
                );

                if (ServicioAutenticacion.Registrar(nuevo))
                {
                    MessageBox.Show("Usuario registrado correctamente.", "Éxito",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Form1 form1 = new Form1();
                    form1.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("El usuario ya existe.", "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar: " + ex.Message);
            }
           
        }

        private void btnEliminarDNI_Click(object sender, EventArgs e)
        {
            
        }

        private void lbRegresar_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();

        }

        private void txtCargo_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
