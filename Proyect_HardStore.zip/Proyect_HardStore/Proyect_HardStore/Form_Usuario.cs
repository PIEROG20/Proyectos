﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    public partial class Form_Usuario : Form
    {
        public Form_Usuario()
        {
            InitializeComponent();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            // Abre el formulario de registro en modo edición pasando el usuario actual
            Usuario user = DatosGlobales.UsuarioLogeado;
            if (user == null)
            {
                MessageBox.Show("No hay usuario logeado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (var frm = new FormRegistrar(user))
            {
                frm.StartPosition = FormStartPosition.CenterParent;
                var result = frm.ShowDialog(this);
                if (result == DialogResult.OK)
                {
                    // Refrescar campos mostrados después de la edición
                    LoadUserFields();
                }
            }
        }

        private void Form_Usuario_Load(object sender, EventArgs e)
        {
            LoadUserFields();
        }

        private void LoadUserFields()
        {
            Usuario user = DatosGlobales.UsuarioLogeado;

            if (user == null)
            {
                MessageBox.Show("No hay usuario logeado.");
                this.Close();
                return;
            }

            txtNombreApellido.Text = user.NombreApellido;
            txtTelefono.Text = user.Telefono.ToString();
            txtDireccion.Text = user.Direccion;
            txtDNI.Text = user.DNI.ToString();
            txtCorreo.Text = user.Correo;
            lbTipoUsuario.Text = user.TipoUsuario;
            txtID.Text = user.IDtrabajador.ToString();
            txtCargo.Text = user.Cargo;
            txtUsuario.Text = user.usuario;
            txtContraseña.Text = user.Contraseña;
        }

        private void lbEditarContraseña_Click(object sender, EventArgs e)
        {
            // Abre el formulario para cambiar la contraseña (cuando se hace clic en la etiqueta)
            using (var frm = new Cambiar_Contraseña())
            {
                frm.StartPosition = FormStartPosition.CenterParent;
                frm.ShowDialog(this);
            }
        }
    }
}
