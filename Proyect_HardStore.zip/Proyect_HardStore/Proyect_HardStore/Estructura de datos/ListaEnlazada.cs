﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    public class NodoP
    {
        public Producto Dato;
        public NodoP Siguiente;

        public NodoP(Producto producto)
        {
            Dato = producto;
            Siguiente = null;
        }
    }
    public class ListaEnlazadaP
    {
        public NodoP Cabeza;
        public ListaEnlazadaP()
        {
            Cabeza = null;
        }

        // INSERSION AL FINAL 
        public void Agregar(Producto cita)
        {
            NodoP nuevo = new NodoP(cita);
            if (Cabeza == null)
            {
                Cabeza = nuevo;
            }
            else
            {
                NodoP actual = Cabeza;
                while (actual.Siguiente != null)
                {
                    actual = actual.Siguiente;
                }
                actual.Siguiente = nuevo;
            }
        }
        public bool EliminarCantidad(string codigo, int cantidadAEliminar)
        {
            NodoP actual = Cabeza;

            while (actual != null)
            {
                if (actual.Dato.Codigo == codigo)
                {
                    if (cantidadAEliminar > actual.Dato.Cantidad)
                        return false; // No hay suficiente cantidad

                    actual.Dato.Cantidad -= cantidadAEliminar;

                    // Si queda en cero, eliminar nodo completo
                    if (actual.Dato.Cantidad == 0)
                        EliminarNodo(codigo);

                    return true; // Eliminación correcta
                }

                actual = actual.Siguiente;
            }

            return false; // No se encontró herramienta
        }

        public Producto BuscarPorId(string codigo)
        {
            NodoP actual = Cabeza;

            while (actual != null)
            {
                if (actual.Dato != null && actual.Dato.Codigo == codigo)
                {
                    return actual.Dato; // se encontró la cita
                }
                actual = actual.Siguiente;
            }

            return null; // no se encontró ninguna cita con ese ID
        }

   
        public bool EliminarNodo(string codigo)
        {
            if (Cabeza == null) return false;

            // Si la cabeza es el nodo a eliminar
            if (Cabeza.Dato.Codigo == codigo)
            {
                Cabeza = Cabeza.Siguiente;
                return true;
            }

            NodoP actual = Cabeza;

            while (actual.Siguiente != null)
            {
                if (actual.Siguiente.Dato.Codigo == codigo)
                {
                    actual.Siguiente = actual.Siguiente.Siguiente;
                    return true;
                }
                actual = actual.Siguiente;
            }

            return false;
        }


        public List<Producto> ConvertirALista()
        {
            List<Producto> lista = new List<Producto>();
            NodoP actual = Cabeza;
            while (actual != null)
            {
                lista.Add(actual.Dato);
                actual = actual.Siguiente;
            }
            return lista;
        }

        // se guarda en un Archivo CSV
        public void GuardarCSV(string rutaArchivo)
        {
            using (StreamWriter sw = new StreamWriter(rutaArchivo, false))
            {
                NodoP actual = Cabeza;

                // Encabezados
                sw.WriteLine("Codigo,Nombre,Cantidad,Proveedor,Precio,Unidad,Categoria,FehcaRegistro");

                while (actual != null)
                {
                    Producto p = actual.Dato;
                    sw.WriteLine($"{p.Codigo},{p.Nombre},{p.Cantidad},{p.Proveedor},{p.Precio},{p.Unidad},{p.Categoria},{p.FechaRegistro}");
                    actual = actual.Siguiente;
                }
            }
        }


        // recupera los datos de archivo CSV y los pone en la lista
        public void CargarDesdeCSV(string rutaArchivo)
        {
            if (!File.Exists(rutaArchivo))
                return;

            Cabeza = null; // limpiar lista

            using (StreamReader sr = new StreamReader(rutaArchivo))
            {
                string linea;
                bool primera = true;

                while ((linea = sr.ReadLine()) != null)
                {
                    if (primera) { primera = false; continue; } // saltar encabezado

                    string[] datos = linea.Split(',');
                    if (datos.Length < 8) continue;

                    Producto p = new Producto()
                    {
                        Codigo = datos[0],
                        Nombre = datos[1],
                        Cantidad = int.Parse(datos[2]),
                        Proveedor = datos[3],
                        Precio = double.Parse(datos[4]),
                        Unidad = datos[5],
                        Categoria = datos[6],
                        FechaRegistro = DateTime.Parse(datos[7]),
                    };

                    Agregar(p);
                }
            }
        }
    }
}
