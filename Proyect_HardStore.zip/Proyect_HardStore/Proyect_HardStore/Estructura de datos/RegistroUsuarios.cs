﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyect_HardStore.Estructura_de_datos
{
    public static class BaseDeDatosUsuarios
    {
        private static string RutaArchivo = "usuarios.csv";

        public static List<Usuario> ListaUsuarios = new List<Usuario>();

        public static void CargarDesdeCsv()
        {
            if (!File.Exists(RutaArchivo))
                return;

            var lineas = File.ReadAllLines(RutaArchivo);
            ListaUsuarios.Clear();

            foreach (var linea in lineas)
            {
                ListaUsuarios.Add(Usuario.CrearDesdeCsv(linea));
            }
        }

        public static void GuardarEnCsv()
        {
            var lineas = ListaUsuarios.Select(u => u.ConvertirACsv()).ToArray();
            File.WriteAllLines(RutaArchivo, lineas);
        }

        public static void AgregarUsuario(Usuario usuario)
        {
            ListaUsuarios.Add(usuario);
            GuardarEnCsv();
        }

        public static Usuario BuscarUsuario(string usuario)
        {
            return ListaUsuarios.FirstOrDefault(u => u.usuario == usuario);
        }

        public static bool EliminarUsuarioPorDNI(int dni)
        {
            var usuario = ListaUsuarios.FirstOrDefault(u => u.DNI == dni);

            if (usuario == null)
                return false; // No existe

            ListaUsuarios.Remove(usuario);
            GuardarEnCsv(); // Reescribe el CSV sin ese usuario
            return true;
        }
    }
    public static class ServicioAutenticacion
    {
        public static bool Registrar(Usuario nuevoUsuario)
        {
            if (BaseDeDatosUsuarios.BuscarUsuario(nuevoUsuario.usuario) != null)
                return false; // Usuario repetido

            BaseDeDatosUsuarios.AgregarUsuario(nuevoUsuario);
            return true;
        }

        public static bool IniciarSesion(string usuario, string contraseña)
        {
            var user = BaseDeDatosUsuarios.BuscarUsuario(usuario);

            if (user == null)
                return false;

            if (user.Contraseña == contraseña)
            {
                DatosGlobales.UsuarioLogeado = user;  // <<< Guarda el usuario logeado
                return true;
            }

            return false;
        }
        //public static bool IniciarSesion(string usuario, string contraseña)
        //{
        //    var user = BaseDeDatosUsuarios.BuscarUsuario(usuario);

        //    if (user == null)
        //        return false;

        //    return user.Contraseña == contraseña;
        //}
    }




}
