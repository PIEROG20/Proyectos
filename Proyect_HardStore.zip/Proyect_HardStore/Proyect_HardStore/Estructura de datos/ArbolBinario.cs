﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyect_HardStore
{
    public class NodoCU
    { 
        public PedidoUsuario Dato { get; set; }
        public NodoCU Izquierdo { get; set; }
        public NodoCU Derecho { get; set; }

        public NodoCU(PedidoUsuario dato)
        {
            Dato = dato;
            Izquierdo = Derecho = null;
        }

    }
    public class ArbolBinario
    {
        public NodoCU Raiz;

        public ArbolBinario()
        {
            Raiz = null;
        }

       
        public void Insertar(PedidoUsuario pedido)
        {
            Raiz = InsertarRecursivo(Raiz, pedido);
        }

        private NodoCU InsertarRecursivo(NodoCU nodo, PedidoUsuario pedido)
        {
            if (nodo == null)
                return new NodoCU(pedido);

            if (nodo.Dato.IDpedido < nodo.Dato.IDpedido)
                nodo.Izquierdo = InsertarRecursivo(nodo.Izquierdo, pedido);
            else
                nodo.Derecho = InsertarRecursivo(nodo.Derecho, pedido);

            return nodo;
        }

     
        public PedidoUsuario BuscarPorID(int id)
        {
            var nodo = Raiz;

            while (nodo != null)
            {
                if (id == nodo.Dato.IDpedido)
                    return nodo.Dato;
                else if (id < nodo.Dato.IDpedido)
                    nodo = nodo.Izquierdo;
                else
                    nodo = nodo.Derecho;
            }

            return null; // No encontrado
        }

        public PedidoUsuario BuscarPorDNI(int dni)
        {
            return BuscarPorDNIRec(Raiz, dni);
        }

        private PedidoUsuario BuscarPorDNIRec(NodoCU nodo, int dni)
        {
            if (nodo == null)
                return null;

            if (nodo.Dato.DNI == dni)
                return nodo.Dato;

            var izquierda = BuscarPorDNIRec(nodo.Izquierdo, dni);
            if (izquierda != null) return izquierda;

            return BuscarPorDNIRec(nodo.Derecho, dni);
        }

        public void GuardarCSV(string ruta)
        {
            using (StreamWriter sw = new StreamWriter(ruta))
            {
                sw.WriteLine("IDpedido - Nombre - Telefono - DNI - Ticket -Productos - MetodoDePago - TipoEntrega - Fecha - Direccion - Referencia - Distrito - PrecioE");
                GuardarInOrden(Raiz, sw);
            }
        }

        private void GuardarInOrden(NodoCU nodo, StreamWriter sw)
        {
            if (nodo == null)
                return;

            GuardarInOrden(nodo.Izquierdo, sw);

            var p = nodo.Dato;

            // Serializar productos
            string productosSerializados = string.Join(";",
                p.ListaProductos.Select(pr => $"{pr.Producto}|{pr.CantidadPedida}|{pr.PrecioUNI}|{pr.PrecioTL}")
            );

            sw.WriteLine($"{p.IDpedido},{p.NombreAppellidos},{p.Telefono},{p.DNI},{p.Ticket}," +
                         $"{productosSerializados},{p.MetodoPago},{p.TipoEntrega}," +
                         $"{p.FechaPedido},{p.Direccion},{p.Referencia},{p.Distrito},{p.PrecioEnvio}");

            GuardarInOrden(nodo.Derecho, sw);
        }

        public void CargarDesdeCSV(string ruta)
        {
            if (!File.Exists(ruta)) return;

            var lineas = File.ReadAllLines(ruta).Skip(1);

            foreach (var linea in lineas)
            {
                var d = linea.Split(',');

                var pedido = new PedidoUsuario
                {
                    IDpedido = int.Parse(d[0]),
                    NombreAppellidos = d[1],
                    Telefono = int.Parse(d[2]),
                    DNI = int.Parse(d[3]),
                    Ticket = d[4],
                    MetodoPago = d[6],
                    TipoEntrega = d[7],
                    FechaPedido = DateTime.Parse(d[8]),
                    Direccion = d[9],
                    Referencia = d[10],
                    Distrito = d[11],
                    PrecioEnvio = int.Parse(d[12])
                };

                // Deserializar productos
                string productosTxt = d[5];

                if (!string.IsNullOrWhiteSpace(productosTxt))
                {
                    var productos = productosTxt.Split(';');

                    foreach (var prod in productos)
                    {
                        var campos = prod.Split('|');
                        pedido.ListaProductos.Add(new PedidoProducto
                        {
                            Producto = campos[0],
                            CantidadPedida= int.Parse(campos[1]),
                            PrecioUNI = double.Parse(campos[2]),
                            PrecioTL = double.Parse(campos[3])
                        });
                    }
                }

                Insertar(pedido);
            }
        }
    }
}
