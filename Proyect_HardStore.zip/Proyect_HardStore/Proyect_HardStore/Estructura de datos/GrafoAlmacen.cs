﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore.Estructura_de_datos
{
    public class NodoAlmacen
    {
        public string Nombre {  get; set; }
        public int PesoPromedio { get; set; }
        public NodoAlmacen(string nombre, int pesoProm)
        {
            Nombre = nombre;
            PesoPromedio = pesoProm;
        }
        
    }
    public class AristaAlmacen
    {
        public int Origen {  get; set; }
        public int Destino { get; set; }
        public int Distancia { get; set; }
        public AristaAlmacen(int origen, int destino, int distancia)
        {
            Origen = origen;
            Destino = destino;
            Distancia = distancia;
        }
    }
    public class GrafoAlmacen
    {
        public int CantidadNodo { get; }
        public NodoAlmacen[] Nodos { get; }
        public int[,] Matriz {  get; }
        public GrafoAlmacen(int nod)
        {
            CantidadNodo = nod;
            Nodos = new NodoAlmacen[nod];
            Matriz = new int[nod, nod];
            for (int i = 0; i < nod; i++)
            {
                for(int j = 0; j< nod; j++)
                {
                    Matriz[i, j] = (i == j ? 0 : int.MaxValue);
                }
            }
        }
        public void AgregarAristas(int a, int b, int distancia)
        {
            Matriz[a, b] = distancia;
            Matriz[b,a] = distancia;
        }
        private int DistanciaMin(int[] dists, bool[] vistado)
        {
            int min = int.MaxValue;
            int index = 0;
            for (int i = 0; i < dists.Length; i++)
                if (!vistado[i] && dists[i] <= min)
                {
                    min = dists[i];
                    index = i;
                }
            return index;
        }
        private List<int> RecostruirRuta(int[] previo, int destino)
        {
            List<int> ruta = new List<int>();
            HashSet<int> visitados = new HashSet<int>();
            int actual = destino;
            while (actual != -1)
            {
                if (visitados.Contains(actual))
                    break;
                visitados.Add(actual);
                ruta.Add(actual);
                actual = previo[actual];
            }
            ruta.Reverse();
            return ruta;
        }
        //BFS
        public List<int> RutaCortaSinpesos(int origen,int destino)
        {
            bool[] viditado = new bool[CantidadNodo];
            int[] previo = new int[CantidadNodo];
            Queue<int> cola = new Queue<int>();
            for(int i = 0;i < CantidadNodo;i++)
                cola.Enqueue(origen);
            viditado[origen] = true;
            while(cola.Count > 0)
            {
                int actual = cola.Dequeue();
                if(actual == origen)
                    break;
                for(int vecino = 0; vecino < CantidadNodo; vecino++)
                {
                    if (!viditado[vecino] && Matriz[actual,vecino] != int.MaxValue)
                    {
                        viditado[vecino] = true;
                        previo[vecino] = actual;
                        cola.Enqueue(vecino);
                    }
                }
            }
            return RecostruirRuta(previo, destino);
        }
        //metodo dijkstra (ese nombre es medio complicado la idea esq es su metodo)
        public List<int> RutaMasCortaPeso(int origen, int destino)
        {
            int[] dists = new int[CantidadNodo];
            bool[] visitad = new bool[CantidadNodo];
            int[] previo = new int[CantidadNodo];
            for(int i = 0;i < CantidadNodo;i++)
            {
                dists[i] = int.MaxValue;
                visitad[i] = false;
                previo[i] = -1;
            }
            dists[origen] = 0;
            for(int i= 0; i< CantidadNodo; i++)
            {
                int u = DistanciaMin(dists, visitad);
                visitad[u] = true;
                for(int v = 0; v < CantidadNodo; v++)
                {
                    if(!visitad[v]&& Matriz[u,v] != int.MaxValue&& dists[u] + Matriz[u,v] < dists[v])
                    {
                        dists[v] = dists[u] + Matriz[u, v];
                        previo[v] = u;

                    }
                }
            }
            return RecostruirRuta(previo, destino);
        }
        private int CalcularDistanciaEuta(List<int> ruta)
        {
            if (ruta == null || ruta.Count < 1) return int.MaxValue;
            int Total = 0;
            for(int i = 0; i < ruta.Count -1; i++)
            {
                int a = ruta[i];
                int b = ruta[i+1];
                if (a < 0 || a >= CantidadNodo || b < 0 || b >= CantidadNodo) return int.MaxValue;
                int peso = Matriz[a, b];
                if (peso == int.MaxValue) return int.MaxValue;
                if(Total > int.MaxValue-peso) return int.MaxValue;
                Total += peso;
            }
            return Total;
        }
        public (List<int> ruta,int distacia) RutaMultidestino(int inicio, List<int> destibos)
        {
            if (inicio < 0 || inicio >= CantidadNodo)
                throw new ArgumentException("Índice de inicio inválido", nameof(inicio));
            var lista = destibos
                .Where(d => d >= 0 && d < CantidadNodo && d != inicio)
                .Distinct()
                .ToList();

            lista = lista.OrderBy(d => Nodos[d].PesoPromedio).ToList();
            List<int> rutaFinal = new List<int>();
            int distanciaTotal = 0;
            int actual = inicio;

            foreach (int dest in lista)
            {
                var tramo = RutaMasCortaPeso(actual, dest);
                if (tramo == null || tramo.Count == 0)
                    continue;
                int tramoDist = CalcularDistanciaEuta(tramo);
                if (tramoDist == int.MaxValue)
                {
                    continue;
                }
                if (rutaFinal.Count > 0 && tramo.Count > 0)
                    tramo.RemoveAt(0);
                rutaFinal.AddRange(tramo);
                distanciaTotal += tramoDist;
                actual = dest;
            }

            return (rutaFinal, distanciaTotal);

        }
        public static GrafoAlmacen CargarGrafo()
        {
            GrafoAlmacen grafoAlmacen = new GrafoAlmacen(9);
            //Nodos
            grafoAlmacen.Nodos[0] = new NodoAlmacen("Area de ventas", 0);
            grafoAlmacen.Nodos[1] = new NodoAlmacen("Manuales", 1);
            grafoAlmacen.Nodos[2] = new NodoAlmacen("Electricas", 2);
            grafoAlmacen.Nodos[3] = new NodoAlmacen("Medición", 3);
            grafoAlmacen.Nodos[4] = new NodoAlmacen("Neumatícas", 4);
            grafoAlmacen.Nodos[5] = new NodoAlmacen("Industrial", 5);
            grafoAlmacen.Nodos[6] = new NodoAlmacen("Soldaduras", 7);
            grafoAlmacen.Nodos[7] = new NodoAlmacen("Construcción", 10);
            grafoAlmacen.Nodos[8] = new NodoAlmacen("Sin Categoria", 99999);
            int d = 1;//distancia por defecto
            //Horizontales
            grafoAlmacen.AgregarAristas(1, 2, d);
            grafoAlmacen.AgregarAristas(2, 3, d);

            grafoAlmacen.AgregarAristas(4, 5, d);
            grafoAlmacen.AgregarAristas(5, 6, d);

            grafoAlmacen.AgregarAristas(7, 8, d);
            grafoAlmacen.AgregarAristas(8, 0, d);
            //Verticales
            grafoAlmacen.AgregarAristas(1, 4, d);
            grafoAlmacen.AgregarAristas(2, 5, d);
            grafoAlmacen.AgregarAristas(3, 6, d);

            grafoAlmacen.AgregarAristas(4, 7, d);
            grafoAlmacen.AgregarAristas(5, 8, d);
            grafoAlmacen.AgregarAristas(6, 0, d);

            return grafoAlmacen;
        }
        Dictionary<string, int> convert = new Dictionary<string, int>()
        {
            {"Manuales", 1 },
            {"Electricas", 2 },
            {"Medicion", 3 },
            {"Neumaticas",4 },
            {"Industrial",5 },
            {"Soldaduras", 6 },
            {"Construccion",7 }
        };
        public List<int> ConvertiraNum(ListBox listabox)
        {
            List<int> numeros = new List<int>();

            foreach (var item in listabox.Items)
            {
                string clave = item.ToString().ToLower();

                if (convert.TryGetValue(clave, out int valor))
                    numeros.Add(valor);
                else
                    numeros.Add(0);
            }

            return numeros;
        }

    }

}
