﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_HardStore
{
    public  class ColaClientes
    {
        private static Queue<ClienteA> cola = new Queue<ClienteA>();
        private static List<ClienteA> atendidos = new List<ClienteA>();
        private static int contador = 1;

        //  Encolar
        public static void Encolar(string usuario)
        {
            ClienteA cliente = new ClienteA()
            {
                Cliente = usuario,
                Atencion = "Compra",
                FechaAtencion = DateTime.Now,
                Ticket = GenerarTicket()
            };

            cola.Enqueue(cliente);
            contador++;
        }

        // Desencolar (devuelve el atendido)
        public static ClienteA Atender()
        {
            if (cola.Count == 0)
            {
                MessageBox.Show("No hay clientes en cola.");
                return null;
            }

            ClienteA atendido = cola.Dequeue();
            atendidos.Add(atendido);
            return atendido;
        }

        public static ClienteA CancelarAtencion()
        {
            if (cola.Count == 0) return null;
            return cola.Dequeue();
        }

        // Obtener en espera 
        public static List<ClienteA> ObtenerCola()
        {
            return cola.ToList();
        }

        //  Obtener atendidos
        public static List<ClienteA> ObtenerAtendidos()
        {
            return atendidos;
        }

        //  Generador de ticket: A0001, A0002...
        private static string GenerarTicket()
        {
            return "AB" + contador.ToString("0000");
        }

        public static ClienteA Primero()
        {
            if (cola.Count == 0)
                return null;

            return cola.Peek();
        }

        // Devuelve una estructura de niveles para visualización en TreeView.
        // Como la implementación actual es una cola, devolvemos todos los elementos en el nivel 0.
        public static Dictionary<int, List<ClienteA>> GetLevels()
        {
            var result = new Dictionary<int, List<ClienteA>>();
            var list = ObtenerCola();
            if (list.Count == 0) return result;
            result[0] = new List<ClienteA>(list);
            return result;
        }
    }
}
