﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPacientes
{

        public class Nodo<Tipo>
        {
        public Tipo Dato;
        public Nodo<Tipo>? siguiente;
        public Nodo(Tipo dato)
        {
            Dato = dato;
            siguiente = null;
        }
    }
}
