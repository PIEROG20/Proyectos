﻿using ListaPacientes;
using System;
namespace ListaPacientes
{
    public class ListaSimple<T>
    {
        private Nodo<T>? cabeza;
        public void Insertar(T dato)
        {
            Nodo<T> nuevo = new Nodo<T>(dato);
            nuevo.siguiente = cabeza;
            cabeza = nuevo;
        }
        //Recorrer
        public void Recorrer()
        {
            if (cabeza == null)
            {
                Console.WriteLine("La lista está vacía.");
                return;
            }
            Nodo<T> actual = cabeza;


            while (actual != null)
            {
                Console.WriteLine(actual.Dato);
                actual = actual.siguiente;
            }
        }
        // Eliminar
        public void Eliminar(Func<T, bool> criterio)
        {
            if (cabeza == null)
            {
                Console.WriteLine("La lista está vacía.");
                return;
            }
            if (criterio(cabeza.Dato))
            {
                cabeza = cabeza.siguiente;
                Console.WriteLine(" Paciente eliminado.");
                return;
            }
            Nodo<T> actual = cabeza;
            while (actual.siguiente != null && !criterio(actual.siguiente.Dato))
            {
                actual = actual.siguiente;
            }


            if (actual.siguiente != null)
            {
                actual.siguiente = actual.siguiente.siguiente;
                Console.WriteLine("paciente eliminado.");
            }
            else
            {
                Console.WriteLine("paciente no encontrado.");
            }
        }
    }
    public class ListasCitas
    {
        public string? CodigoPaciente { get; set; }
        public string? Paciente { get; set; }
        public string? Especialidad { get; set; }
        public string? Fecha { get; set; }
        public override string ToString()
        {
            return $"[Cita] CodigoPaciente:{CodigoPaciente}, Paciente: {Paciente}, Especialidad: {Especialidad}, Fecha: {Fecha} ";
        }
    }
}
