namespace G3_edad.Entidades
{
    public class G3_Producto
    {
        public int G3_Id { get; set; }
        public string G3_Nombre { get; set; }
        public string G3_Categoria { get; set; }
        public decimal G3_Precio { get; set; }
        public int G3_Stock { get; set; }
    }
}