namespace G3_edad.Entidades
{
    public class G3_Cliente
    {
        public int G3_Id { get; set; }
        public string G3_Nombre { get; set; }
        public string G3_Apellido { get; set; }
        public string G3_DNI { get; set; }
        public string G3_Celular { get; set; }
    }
}